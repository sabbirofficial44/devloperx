const fs=require('fs');
const dash=fs.readFileSync('D:/Script/VeuUnlimited/extension/dashboard-template.html','utf8');
const server=fs.readFileSync('D:/Script/VeuUnlimited/extension/dev-server.js','utf8');

const start=server.indexOf('const DASHBOARD_HTML');
const end=server.indexOf('const ADMIN_HTML');

// Escape for template literal
const escaped=dash
  .replace(/\\/g,'\\\\')
  .replace(/`/g,'\\`')
  .replace(/\$/g,'\\$');

const newServer=server.substring(0,start)+'const DASHBOARD_HTML = `'+escaped+'`;\n\n'+server.substring(end);
fs.writeFileSync('D:/Script/VeuUnlimited/extension/dev-server.js',newServer,'utf8');
console.log('Done. Length:',newServer.length);
// Verify
const verify=fs.readFileSync('D:/Script/VeuUnlimited/extension/dev-server.js','utf8');
if(verify.includes('DASHBOARD_HTML')&&verify.includes('ADMIN_HTML')){
  console.log('OK - both sections present');
}
