const fs=require('fs');
const js=fs.readFileSync('D:/Script/VeuUnlimited/extension/popup.js','utf8');
const html=fs.readFileSync('D:/Script/VeuUnlimited/extension/popup.html','utf8');

console.log('=== JS CHECK ===');
if(js.includes('***')) console.log('CORRUPTED - has ***');
else console.log('Clean - no ***');

const passIdx=js.indexOf('pass=');
if(passIdx>=0) {
  const line=js.substring(passIdx,passIdx+80).replace(/[\r\n]/g,'\\n');
  console.log('pass line:',line);
  if(line.includes('getElementById')) console.log('  -> has getElementById');
  else console.log('  -> MISSING getElementById');
}

if(js.includes('loginBtn')) console.log('has loginBtn reference');
else console.log('MISSING loginBtn');
if(js.includes('emailInput')) console.log('has emailInput reference');
else console.log('MISSING emailInput');
if(js.includes('passInput')) console.log('has passInput reference');
else console.log('MISSING passInput');

console.log('');
console.log('=== HTML CHECK ===');
const emailId=html.match(/id="([^"]*mail[^"]*)"/);
const passId=html.match(/id="([^"]*[Pp]ass[^"]*)"/);
console.log('email input id:',emailId?emailId[1]:'NOT FOUND');
console.log('pass input id:',passId?passId[1]:'NOT FOUND');
if(html.includes('popup.js')) console.log('loads popup.js');
else console.log('MISSING script tag');

console.log('');
console.log('=== FIX: Complete rewrite if broken ===');
if(!js.includes('getElementById("passInput")') || !html.match(/id="passInput"/)) {
  console.log('NEEDS FIX - will rewrite');
} else {
  console.log('Everything looks correct structurally');
}
