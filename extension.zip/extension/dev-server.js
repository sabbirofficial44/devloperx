// ═══════════════════════════════════════════════════════════════
//  DeveloperX — Full SaaS API Server
//  File-based DB  |  Trial/Subscription/Credit Management
// ═══════════════════════════════════════════════════════════════

import { createServer } from 'http';
import { readFileSync, writeFileSync, existsSync, mkdirSync } from 'fs';
import { createHash, randomUUID } from 'crypto';
import { join, dirname } from 'path';
import { fileURLToPath } from 'url';

const __dirname = dirname(fileURLToPath(import.meta.url));
const DATA_DIR = join(__dirname, '..', 'veu-data');
const DB_FILE = join(DATA_DIR, 'db.json');

const PORT = 8090;

// ─── CORS headers on every response ───
const CORS = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS, PATCH',
  'Access-Control-Allow-Headers': 'Content-Type, Authorization, X-Admin-Key',
  'Access-Control-Max-Age': '86400',
};

// ═══════════════════════════════════════════════════
//  Database
// ═══════════════════════════════════════════════════
const DEFAULT_DB = {
  users: {},
  global_cookies: [],
  credit_ledger: [],
  admin_key: 'admin',
};

function loadDB() {
  if (!existsSync(DATA_DIR)) mkdirSync(DATA_DIR, { recursive: true });
  if (!existsSync(DB_FILE)) {
    writeFileSync(DB_FILE, JSON.stringify(DEFAULT_DB, null, 2));
    return JSON.parse(JSON.stringify(DEFAULT_DB));
  }
  const raw = JSON.parse(readFileSync(DB_FILE, 'utf8'));
  // Merge missing top-level keys from defaults
  let changed = false;
  for (const [k, v] of Object.entries(DEFAULT_DB)) {
    if (!(k in raw)) { raw[k] = v; changed = true; }
  }
  if (changed) writeFileSync(DB_FILE, JSON.stringify(raw, null, 2));
  return raw;
}

function saveDB(db) {
  writeFileSync(DB_FILE, JSON.stringify(db, null, 2));
}

let db = loadDB();

// ─── Helpers ───
function json(res, data, status = 200) {
  res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8', ...CORS });
  res.end(JSON.stringify(data));
}

function parseBody(req) {
  return new Promise(resolve => {
    let body = '';
    req.on('data', c => body += c);
    req.on('end', () => {
      try { resolve(JSON.parse(body)); }
      catch { resolve({}); }
    });
  });
}

function sha256(s) {
  return createHash('sha256').update(s).digest('hex');
}

function getAdminKey() {
  return db.admin_key || DEFAULT_DB.admin_key;
}

function isAdmin(req) {
  const key = req.headers['x-admin-key'] || '';
  return key === getAdminKey();
}

// ═══════════════════════════════════════════════════
//  Limit / Trial Logic
// ═══════════════════════════════════════════════════
// Convert hours+minutes to total minutes, always return a usable number
function totalTimeMins(user) {
  const h = user.credit_hours ?? user.trial_hours ?? 0;
  const m = user.credit_minutes ?? 0;
  return (h * 60) + m;
}

function remainingTimeMins(user) {
  const total = totalTimeMins(user);
  const used = user.minutes_used ?? 0;
  return Math.max(0, total - used);
}

function checkLimits(user) {
  if (!user) return { ok: false, blocked: true, blockReason: 'User not found' };

  if (user.disabled) {
    return { ok: false, blocked: true, blockReason: 'Account disabled by admin' };
  }

  // Subscription expiry (absolute)
  if (user.expires_at) {
    if (Date.now() > new Date(user.expires_at).getTime()) {
      return { ok: false, blocked: true, blockReason: 'Subscription expired' };
    }
  }

  // Time-based usage check
  const totalMins = totalTimeMins(user);
  const usedMins = user.minutes_used ?? 0;

  if (totalMins > 0 && usedMins >= totalMins) {
    return { ok: false, blocked: true, blockReason: 'Time exhausted. Upgrade your plan to continue.' };
  }

  return { ok: true, blocked: false, blockReason: null };
}

// Build a full user response for verify / login
function userResponse(user) {
  const limitCheck = checkLimits(user);
  const totalMins = totalTimeMins(user);
  const usedMins = user.minutes_used ?? 0;
  const remMins = remainingTimeMins(user);
  const totalHrs = Math.floor(totalMins / 60);
  const totalMin = totalMins % 60;
  const usedHrs = Math.floor(usedMins / 60);
  const usedMin = usedMins % 60;
  const remHrs = Math.floor(remMins / 60);
  const remMin = remMins % 60;

  const base = {
    valid: limitCheck.ok,
    blocked: limitCheck.blocked,
    blockReason: limitCheck.blockReason || null,
    cookies: db.global_cookies || [],
    plan: user.plan || 'trial',
    expiresAt: user.expires_at || null,
    totalTime: totalMins, totalTimeStr: totalHrs + 'h ' + totalMin + 'm',
    usedTime: usedMins, usedTimeStr: usedHrs + 'h ' + usedMin + 'm',
    remainingTime: remMins, remainingTimeStr: remHrs + 'h ' + remMin + 'm',
    creditsLeft: remMins, credits: remMins,
    user: {
      id: user.user_id,
      name: user.display_name || user.email.split('@')[0],
      email: user.email,
      plan: user.plan || 'trial',
      totalTime: totalMins, totalTimeStr: totalHrs + 'h ' + totalMin + 'm',
      usedTime: usedMins, usedTimeStr: usedHrs + 'h ' + usedMin + 'm',
      remainingTime: remMins, remainingTimeStr: remHrs + 'h ' + remMin + 'm',
      creditsLeft: remMins, creditsUsed: usedMins, creditsTotal: totalMins,
      expiresAt: user.expires_at || null,
      blocked: limitCheck.blocked, blockReason: limitCheck.blockReason || null,
    },
  };

  return limitCheck.ok ? { ...base, valid: true, ok: true } : base;
}

// ═══════════════════════════════════════════════════
//  Server
// ═══════════════════════════════════════════════════
const server = createServer(async (req, res) => {
  const url = new URL(req.url, 'http://localhost:' + PORT);
  const path = url.pathname;
  db = loadDB();

  // Handle CORS preflight
  if (req.method === 'OPTIONS') {
    res.writeHead(204, CORS);
    res.end();
    return;
  }

  // ═══════════════ PUBLIC ENDPOINTS ═══════════════

  // ── Health ──
  if (path === '/health' && req.method === 'GET') {
    return json(res, { ok: true, mode: 'saas', brand: 'DeveloperX', users: Object.keys(db.users).length });
  }

  // ── Register (POST /api/public/auth/register) ──
  if (path === '/api/public/auth/register' && req.method === 'POST') {
    const body = await parseBody(req);
    const email = (body.email || '').toLowerCase().trim();
    if (!email || !body.password) return json(res, { error: 'Email and password required' }, 400);
    if (db.users[email]) return json(res, { error: 'Email already registered. Please login.' }, 409);

    const plan = body.plan || 'trial';
    const planConfig = {
      trial:     { credit_hours: 5,  credit_minutes: 0,  days: 0,  plan: 'trial' },
      '1hr':     { credit_hours: 1,  credit_minutes: 0,  days: 1,  plan: 'daily' },
      '5hr':     { credit_hours: 5,  credit_minutes: 0,  days: 3,  plan: 'weekly' },
      '24hr':    { credit_hours: 24, credit_minutes: 0,  days: 7,  plan: 'basic' },
      '7days':   { credit_hours: 168,credit_minutes: 0,  days: 7,  plan: 'pro' },
      '30days':  { credit_hours: 720,credit_minutes: 0,  days: 30, plan: 'unlimited' },
      daily:     { credit_hours: 1,  credit_minutes: 0,  days: 1,  plan: 'daily' },
      weekly:    { credit_hours: 5,  credit_minutes: 0,  days: 7,  plan: 'weekly' },
      monthly:   { credit_hours: 24, credit_minutes: 0,  days: 30, plan: 'basic' },
      pro:       { credit_hours: 168,credit_minutes: 0,  days: 30, plan: 'pro' },
      unlimited: { credit_hours: 9999,credit_minutes:0,  days: 0,  plan: 'unlimited' },
    };
    const config = planConfig[plan] || planConfig.trial;
    const expires = config.days > 0 ? new Date(Date.now() + config.days * 86400_000).toISOString() : null;

    db.users[email] = {
      user_id: 'dx_' + randomUUID().slice(0, 12),
      email,
      password_hash: sha256(body.password),
      display_name: body.display_name || email.split('@')[0],
      plan: config.plan,
      credit_hours: config.credit_hours,
      credit_minutes: config.credit_minutes,
      minutes_used: 0,
      expires_at: expires,
      trial_hours: config.credit_hours,
      trial_used: false,
      disabled: false,
      created_at: new Date().toISOString(),
      last_login: null,
    };
    saveDB(db);

    return json(res, {
      ok: true,
      user: {
        id: db.users[email].user_id, name: db.users[email].display_name, email,
        plan: config.plan, creditsTotal: config.credit_limit, creditsUsed: 0,
        creditsLeft: config.credit_limit, expiresAt: expires,
        trialHours: config.trial_hours,
      },
    });
  }

  // ── Login (POST /api/public/auth/login) ──
  // Auto-create user if not exists.  New users get trial=5h, plan="trial"
  if (path === '/api/public/auth/login' && req.method === 'POST') {
    const body = await parseBody(req);
    const email = (body.email || 'user@developersx.dev').toLowerCase().trim();
    const password = body.password || 'pass123';

    let user = db.users[email];

    if (!user) {
      // Auto-create → trial mode
      user = {
        user_id: 'dx_' + randomUUID().slice(0, 12),
        email,
        password_hash: sha256(password),
        display_name: body.display_name || email.split('@')[0],
        plan: 'trial',
        credit_hours: 5,
        credit_minutes: 0,
        minutes_used: 0,
        expires_at: null,
        created_at: new Date().toISOString(),
        disabled: false,
        last_login: null,
        trial_hours: 5,
        trial_used: false,
      };
      db.users[email] = user;
    }

    // Blocked?
    const limitCheck = checkLimits(user);
    if (limitCheck.blocked) {
      saveDB(db);
      return json(res, { message: limitCheck.blockReason, blocked: true, blockReason: limitCheck.blockReason }, 403);
    }

    user.last_login = new Date().toISOString();
    saveDB(db);

    const resp = userResponse(user);
    return json(res, {
      accessToken: user.user_id + ':' + email,
      refreshToken: 'refresh_' + user.user_id,
      user: resp.user,
      valid: true,
      blocked: resp.blocked,
      blockReason: resp.blockReason || null,
      cookies: db.global_cookies || [],
    });
  }

  // ── Verify (GET /api/verify?userId=X) ──
  if (path === '/api/verify' && req.method === 'GET') {
    const userId = url.searchParams.get('userId');
    if (!userId) return json(res, { valid: false, blocked: true, blockReason: 'Missing userId' }, 400);

    const user = Object.values(db.users).find(u => u.user_id === userId);
    if (!user) return json(res, { valid: false, blocked: true, blockReason: 'User not found' }, 401);

    return json(res, userResponse(user));
  }

  // ── Deduct credits (POST /api/public/extension/deduct) ──
  if (path === '/api/public/extension/deduct' && req.method === 'POST') {
    const body = await parseBody(req);
    const userId = body.userId || body.user_id;
    const user = Object.values(db.users).find(u => u.user_id === userId);
    if (!user) return json(res, { error: 'User not found' }, 404);

    const limitCheck = checkLimits(user);
    if (limitCheck.blocked) {
      return json(res, { error: limitCheck.blockReason, blocked: true, blockReason: limitCheck.blockReason }, 402);
    }

    // Time-based: amount is minutes (can be fractional, e.g. 0.166 = 10 seconds)
    const amount = Math.max(0.01, Number(body.amount ?? 1));
    user.minutes_used = (user.minutes_used || 0) + amount;

    const remMins = remainingTimeMins(user);
    const remHrs = Math.floor(remMins / 60);
    const remMin = Math.round((remMins % 60) * 10) / 10;

    db.credit_ledger.push({
      id: randomUUID(),
      user_id: userId,
      email: user.email,
      amount: -amount,
      unit: 'minutes',
      reason: body.reason || 'usage',
      source: body.source || 'extension',
      balance_after_minutes: remMins,
      created_at: new Date().toISOString(),
    });

    saveDB(db);
    return json(res, {
      success: true,
      deducted: amount,
      unit: 'minutes',
      remainingTime: remMins,
      remainingTimeStr: remHrs + 'h ' + remMin + 'm',
    });
  }

  // ── Generate (POST /api/public/extension/generate) ──
  if (path === '/api/public/extension/generate' && req.method === 'POST') {
    const body = await parseBody(req);
    const userId = body.userId || body.user_id;
    const user = Object.values(db.users).find(u => u.user_id === userId);
    if (!user) return json(res, { success: true, creditsLeft: 999999 });

    const limitCheck = checkLimits(user);
    if (limitCheck.blocked) {
      return json(res, { success: false, error: limitCheck.blockReason, blocked: true, blockReason: limitCheck.blockReason }, 402);
    }

    const total = user.credit_limit ?? 0;
    const used = user.credits_used ?? 0;
    return json(res, {
      success: true,
      creditsLeft: total - used,
    });
  }

  // ── Reset password (POST /api/public/auth/reset-password) ──
  if (path === '/api/public/auth/reset-password' && req.method === 'POST') {
    const body = await parseBody(req);
    const userId = body.userId || body.user_id;
    const user = Object.values(db.users).find(u => u.user_id === userId);
    if (!user) return json(res, { ok: false, message: 'User not found' }, 404);
    if (body.newPassword) user.password_hash = sha256(body.newPassword);
    saveDB(db);
    return json(res, { ok: true });
  }

  // ═══════════════ PUBLIC PAGES ═══════════════
  if (path === '/register') {
    res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8', ...CORS });
    res.end(REGISTER_HTML);
    return;
  }
  if (path === '/login' && req.method === 'GET') {
    res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8', ...CORS });
    res.end(LOGIN_HTML);
    return;
  }
  if (path === '/dashboard') {
    res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8', ...CORS });
    res.end(DASHBOARD_HTML);
    return;
  }

  // ═══════════════ ADMIN PANEL (HTML) ═══════════════
  if (path === '/admin') {
    const html = ADMIN_HTML;
    res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8', ...CORS });
    res.end(html);
    return;
  }

  // ═══════════════ PUBLIC LANDING PAGE ═══════════════
  // Served at / (root) — DeveloperX sales site
  if (path === '/' || path === '/landing') {
    res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8', ...CORS });
    res.end(LANDING_HTML);
    return;
  }

  // ═══════════════ ADMIN API ENDPOINTS ═══════════════

  // ── Admin login ──
  if (path === '/admin/login' && req.method === 'POST') {
    const body = await parseBody(req);
    if (body.key === getAdminKey()) {
      return json(res, { ok: true, message: 'Authenticated' });
    }
    return json(res, { ok: false, message: 'Invalid admin key' }, 401);
  }

  // All further /admin/* routes require admin key
  if (!isAdmin(req)) {
    if (path.startsWith('/admin/')) return json(res, { error: 'Unauthorized' }, 401);
    return json(res, { error: 'Not found' }, 404);
  }

  // ── GET /admin/users ──
  if (path === '/admin/users' && req.method === 'GET') {
    const users = Object.values(db.users).map(u => ({
      user_id: u.user_id,
      email: u.email,
      display_name: u.display_name,
      plan: u.plan,
      credit_limit: u.credit_limit,
      credits_used: u.credits_used,
      credits_used_today: u.credits_used_today,
      daily_credit_limit: u.daily_credit_limit,
      expires_at: u.expires_at,
      disabled: u.disabled,
      created_at: u.created_at,
      last_login: u.last_login,
      trial_hours: u.trial_hours,
      trial_used: u.trial_used,
      password_hash: undefined, // never leak
    }));
    return json(res, { users });
  }

  // ── POST /admin/users/create ──
  if (path === '/admin/users/create' && req.method === 'POST') {
    const body = await parseBody(req);
    const email = (body.email || '').toLowerCase().trim();
    if (!email || !body.password) return json(res, { error: 'Email and password required' }, 400);
    if (db.users[email]) return json(res, { error: 'Email already exists' }, 409);

    const days = body.expires_in_days ?? (body.expires_in_days === 0 ? 0 : 30);
    const expires = days > 0 ? new Date(Date.now() + days * 86400_000).toISOString() : null;

    db.users[email] = {
      user_id: 'dx_' + randomUUID().slice(0, 12),
      email,
      password_hash: sha256(body.password),
      display_name: body.display_name || email.split('@')[0],
      plan: body.plan || 'trial',
      credit_hours: Number(body.credit_hours ?? body.credit_limit ?? 5),
      credit_minutes: Number(body.credit_minutes ?? 0),
      minutes_used: 0,
      expires_at: expires,
      disabled: false,
      created_at: new Date().toISOString(),
      last_login: null,
      trial_hours: Number(body.trial_hours ?? body.credit_hours ?? body.credit_limit ?? 5),
      trial_used: body.trial_used ?? false,
    };
    saveDB(db);
    return json(res, { ok: true, email, password: body.password });
  }

  // ── POST /admin/users/update ──
  if (path === '/admin/users/update' && req.method === 'POST') {
    const body = await parseBody(req);
    const user = Object.values(db.users).find(u => u.user_id === body.user_id);
    if (!user) return json(res, { error: 'User not found' }, 404);

    if (body.credit_hours !== undefined) user.credit_hours = Number(body.credit_hours);
    if (body.credit_minutes !== undefined) user.credit_minutes = Number(body.credit_minutes);
    if (body.plan !== undefined) user.plan = body.plan;
    if (body.display_name !== undefined) user.display_name = body.display_name;
    if (body.disabled !== undefined) user.disabled = Boolean(body.disabled);
    if (body.trial_hours !== undefined) user.trial_hours = Number(body.trial_hours);
    if (body.trial_used !== undefined) user.trial_used = Boolean(body.trial_used);
    if (body.minutes_used !== undefined) user.minutes_used = Math.max(0, Number(body.minutes_used));
    if (body.expires_in_days !== undefined) {
      const d = Number(body.expires_in_days);
      user.expires_at = d > 0 ? new Date(Date.now() + d * 86400_000).toISOString() : null;
    }
    if (body.expires_at !== undefined) {
      user.expires_at = body.expires_at || null;
    }

    saveDB(db);
    return json(res, { ok: true });
  }

  // ── POST /admin/users/delete ──
  if (path === '/admin/users/delete' && req.method === 'POST') {
    const body = await parseBody(req);
    const user = Object.values(db.users).find(u => u.user_id === body.user_id);
    if (!user) return json(res, { error: 'User not found' }, 404);
    delete db.users[user.email];
    saveDB(db);
    return json(res, { ok: true });
  }

  // ── POST /admin/users/reset-credits ──
  if (path === '/admin/users/reset-credits' && req.method === 'POST') {
    const body = await parseBody(req);
    const user = Object.values(db.users).find(u => u.user_id === body.user_id);
    if (!user) return json(res, { error: 'User not found' }, 404);
    user.credits_used = 0;
    user.credits_used_today = {};
    saveDB(db);
    return json(res, { ok: true });
  }

  // ── POST /admin/users/bulk-create ──
  if (path === '/admin/users/bulk-create' && req.method === 'POST') {
    const body = await parseBody(req);
    const count = Math.min(200, Math.max(1, Number(body.count) || 10));
    const domain = (body.domain || 'flowmail.local').replace(/^@+/, '');
    const days = body.expires_in_days ?? 30;
    const expires = days > 0 ? new Date(Date.now() + days * 86400_000).toISOString() : null;
    const creditLimit = body.credits !== undefined ? Number(body.credits) : 1000;
    const results = [];
    const chars = 'abcdefghijklmnopqrstuvwxyz0123456789';

    for (let i = 0; i < count; i++) {
      const prefix = (body.prefix || 'dx').toLowerCase().replace(/[^a-z0-9]/g, '');
      let rnd = '';
      for (let j = 0; j < 8; j++) rnd += chars[Math.floor(Math.random() * chars.length)];
      const email = prefix + '_' + rnd + '@' + domain;
      const pwchars = 'abcdefghjkmnpqrstuvwxyz23456789';
      let pw = '';
      for (let j = 0; j < 10; j++) pw += pwchars[Math.floor(Math.random() * pwchars.length)];

      if (db.users[email]) {
        results.push({ email, password: pw, ok: false, error: 'duplicate' });
        continue;
      }

      db.users[email] = {
        user_id: 'dx_' + randomUUID().slice(0, 12),
        email,
        password_hash: sha256(pw),
        display_name: email.split('@')[0],
        plan: 'trial',
        credit_hours: creditLimit,
        credit_minutes: 0,
        minutes_used: 0,
        trial_hours: creditLimit,
        expires_at: expires,
        disabled: false,
        created_at: new Date().toISOString(),
        last_login: null,
        trial_hours: 5,
        trial_used: false,
      };
      results.push({ email, password: pw, ok: true });
    }

    saveDB(db);
    return json(res, { results });
  }

  // ── GET /admin/ledger ──
  if (path === '/admin/ledger' && req.method === 'GET') {
    const entries = (db.credit_ledger || []).slice(-500).reverse();
    return json(res, { entries });
  }

  // ── GET /admin/stats ──
  if (path === '/admin/stats' && req.method === 'GET') {
    const users = Object.values(db.users);
    const now = Date.now();
    const active = users.filter(u => !u.disabled);
    const expired = users.filter(u => {
      if (u.expires_at && new Date(u.expires_at).getTime() < now) return true;
      if (u.trial_hours > 0 && !u.trial_used) {
        const created = new Date(u.created_at).getTime();
        return now > created + u.trial_hours * 3600_000;
      }
      return false;
    });
    const totalCreditsUsed = users.reduce((sum, u) => sum + (u.minutes_used || 0), 0);
    const totalCreditsGranted = users.reduce((sum, u) => sum + ((u.credit_hours||0) * 60 + (u.credit_minutes||0)), 0);

    return json(res, {
      totalUsers: users.length,
      activeUsers: active.length,
      expiredUsers: expired.length,
      disabledUsers: users.filter(u => u.disabled).length,
      totalCreditsUsed,
      totalCreditsGranted,
      trialUsers: users.filter(u => u.plan === 'trial').length,
    });
  }

  // ── POST /admin/cookies/fetch-live ──
  // Fetch live cookies from external source (veoly.netlify.app)
  if (path === '/admin/cookies/fetch-live' && req.method === 'POST') {
    try {
      const r = await fetch('https://veoly.netlify.app/api/verify', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId: 'admin', sessionToken: 'admin:admin@developerx.dev' })
      });
      if (!r.ok) return json(res, { ok: false, error: 'External server returned ' + r.status }, 502);
      const j = await r.json();
      const cookies = j.cookies || [];
      if (cookies.length > 0) {
        db.global_cookies = cookies;
        saveDB(db);
        return json(res, { ok: true, count: cookies.length, source: 'veoly.netlify.app', cookies });
      }
      return json(res, { ok: false, error: 'No cookies from external source', count: 0 });
    } catch (e) {
      return json(res, { ok: false, error: 'Fetch failed: ' + e.message }, 502);
    }
  }

  // ── POST /admin/cookies/update ──
  if (path === '/admin/cookies/update' && req.method === 'POST') {
    const body = await parseBody(req);
    const arr = Array.isArray(body) ? body : (body.cookies || []);
    db.global_cookies = arr;
    saveDB(db);
    return json(res, { ok: true, count: arr.length });
  }

  // ── GET /admin/cookies ──
  if (path === '/admin/cookies' && req.method === 'GET') {
    return json(res, { count: (db.global_cookies || []).length, cookies: db.global_cookies });
  }

  // ── /admin/users/list (backwards compat) ──
  if (path === '/admin/users/list' && req.method === 'GET') {
    const users = Object.values(db.users).map(u => ({
      user_id: u.user_id, email: u.email, display_name: u.display_name,
      plan: u.plan, credit_hours: u.credit_hours, credit_minutes: u.credit_minutes, minutes_used: u.minutes_used,
      expires_at: u.expires_at, disabled: u.disabled, created_at: u.created_at,
      last_login: u.last_login, trial_hours: u.trial_hours, trial_used: u.trial_used,
      password_hash: undefined,
    }));
    return json(res, { users });
  }

  // ── /admin/users/toggle (backwards compat) ──
  if (path === '/admin/users/toggle' && req.method === 'POST') {
    const body = await parseBody(req);
    const user = Object.values(db.users).find(u => u.user_id === body.user_id);
    if (!user) return json(res, { error: 'Not found' }, 404);
    user.disabled = !user.disabled;
    saveDB(db);
    return json(res, { ok: true, disabled: user.disabled });
  }

  // 404 fallback
  json(res, { error: 'Not found' }, 404);
});

// ═══════════════════════════════════════════════════════════════
//  PUBLIC LANDING PAGE — DeveloperX Sales Site
// ═══════════════════════════════════════════════════════════════
const LANDING_HTML = `<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>DeveloperX — Unlimited Video Generation</title>
<style>
:root{--bg:#08090d;--card:#101217;--border:#1e2030;--text:#e4e6f0;--muted:#6b7084;--purple:#7c5cfc;--gold:#f0b90b;--green:#10b981;--red:#ef4444}
*{margin:0;padding:0;box-sizing:border-box}
body{font-family:system-ui,-apple-system,sans-serif;background:var(--bg);color:var(--text);line-height:1.6}
.container{max-width:1100px;margin:0 auto;padding:0 20px}
/* Nav */
nav{display:flex;justify-content:space-between;align-items:center;padding:16px 0;border-bottom:1px solid var(--border)}
.logo{font-size:22px;font-weight:800;background:linear-gradient(135deg,var(--purple),#a78bfa);-webkit-background-clip:text;-webkit-text-fill-color:transparent}
.nav-links{display:flex;gap:20px;align-items:center}
.nav-links a{color:var(--muted);text-decoration:none;font-size:14px;transition:color .2s}
.nav-links a:hover{color:var(--text)}
.btn{padding:10px 20px;border-radius:8px;font-weight:600;font-size:13px;cursor:pointer;border:none;text-decoration:none;display:inline-block;transition:all .2s}
.btn-purple{background:var(--purple);color:#fff}
.btn-purple:hover{box-shadow:0 0 24px rgba(124,92,252,.4);transform:translateY(-1px)}
.btn-outline{border:1px solid var(--border);color:var(--text);background:transparent}
.btn-gold{background:linear-gradient(135deg,var(--gold),#fbbf24);color:#000;font-weight:700}
/* Hero */
.hero{padding:80px 0 60px;text-align:center}
.hero h1{font-size:42px;font-weight:800;line-height:1.2;margin-bottom:16px;background:linear-gradient(135deg,var(--purple),#a78bfa,var(--gold));-webkit-background-clip:text;-webkit-text-fill-color:transparent}
.hero p{font-size:17px;color:var(--muted);max-width:600px;margin:0 auto 28px}
.hero-badges{display:flex;justify-content:center;gap:12px;flex-wrap:wrap;margin-bottom:28px}
.badge{display:inline-flex;align-items:center;gap:6px;padding:6px 14px;background:var(--card);border:1px solid var(--border);border-radius:20px;font-size:12px;color:var(--muted)}
.badge .dot{width:8px;height:8px;border-radius:50%;background:var(--green)}
/* Cards */
.section{padding:60px 0}
.section h2{font-size:28px;font-weight:700;text-align:center;margin-bottom:12px}
.section .subtitle{text-align:center;color:var(--muted);margin-bottom:40px;font-size:15px}
.pricing-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:16px}
.price-card{background:var(--card);border:1px solid var(--border);border-radius:12px;padding:24px;text-align:center;transition:all .3s;position:relative}
.price-card:hover{border-color:var(--purple);transform:translateY(-4px);box-shadow:0 8px 32px rgba(124,92,252,.15)}
.price-card.featured{border-color:var(--purple);box-shadow:0 0 24px rgba(124,92,252,.1)}
.price-card.featured::before{content:'POPULAR';position:absolute;top:-10px;left:50%;transform:translateX(-50%);background:var(--purple);color:#fff;font-size:10px;font-weight:700;padding:3px 12px;border-radius:10px;letter-spacing:1px}
.plan-name{font-size:16px;font-weight:700;margin-bottom:4px;color:var(--purple)}
.plan-credits{font-size:28px;font-weight:800;margin-bottom:2px}
.plan-duration{font-size:12px;color:var(--muted);margin-bottom:12px}
.plan-price{font-size:20px;font-weight:700;color:var(--gold);margin-bottom:16px}
/* Features */
.features-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(240px,1fr));gap:20px}
.feature-card{background:var(--card);border:1px solid var(--border);border-radius:12px;padding:24px}
.feature-card h3{font-size:15px;margin-bottom:8px}
.feature-card p{color:var(--muted);font-size:13px}
.steps{display:grid;grid-template-columns:repeat(3,1fr);gap:20px;text-align:center}
.step-num{width:48px;height:48px;border-radius:50%;background:var(--purple);color:#fff;font-size:20px;font-weight:700;display:flex;align-items:center;justify-content:center;margin:0 auto 12px}
.step h3{font-size:15px;margin-bottom:6px}
.step p{color:var(--muted);font-size:13px}
/* Extension */
.extension-box{background:var(--card);border:1px solid var(--border);border-radius:12px;padding:32px;text-align:center;max-width:500px;margin:0 auto}
.extension-box h3{font-size:18px;margin-bottom:8px}
.extension-box ol{text-align:left;color:var(--muted);font-size:13px;padding-left:20px;line-height:2}
footer{text-align:center;padding:40px 0;border-top:1px solid var(--border);color:var(--muted);font-size:12px}
@media(max-width:768px){.hero h1{font-size:28px}.steps{grid-template-columns:1fr}}
</style>
</head>
<body>
<div class="container">
<nav><div class="logo">DeveloperX</div>
<div class="nav-links"><a href="#pricing">Pricing</a><a href="#features">Features</a><a href="/register" class="btn btn-purple">Get Started</a><a href="/login">Login</a></div>
</nav>

<section class="hero">
<h1>Unlimited Video Generation<br>with Google Flow</h1>
<p>Access Veo, Omni, and Flash AI video models through a simple Chrome extension. No limits, no hassle.</p>
<div class="hero-badges">
<span class="badge"><span class="dot"></span> Veo 3</span>
<span class="badge"><span class="dot"></span> Omni</span>
<span class="badge"><span class="dot"></span> Flash</span>
<span class="badge"><span class="dot"></span> 24/7 Support</span>
</div>
<a href="/register" class="btn btn-gold" style="font-size:16px;padding:14px 36px">Start Free Trial — 5 Hours</a>
</section>

<section class="section" id="pricing">
<h2>Choose Your Plan</h2>
<p class="subtitle">All plans include full access to all AI models. Cancel anytime.</p>
<div class="pricing-grid">
<div class="price-card"><div class="plan-name">DAILY</div><div class="plan-credits">20</div><div class="plan-duration">credits / day</div><div class="plan-price">৳50</div><a href="/register" class="btn btn-purple" style="width:100%">Get Started</a></div>
<div class="price-card"><div class="plan-name">WEEKLY</div><div class="plan-credits">100</div><div class="plan-duration">credits / week</div><div class="plan-price">৳200</div><a href="/register" class="btn btn-purple" style="width:100%">Get Started</a></div>
<div class="price-card featured"><div class="plan-name">MONTHLY</div><div class="plan-credits">500</div><div class="plan-duration">credits / month</div><div class="plan-price">৳500</div><a href="/register" class="btn btn-purple" style="width:100%">Get Started</a></div>
<div class="price-card"><div class="plan-name">PRO</div><div class="plan-credits">2000</div><div class="plan-duration">credits / month</div><div class="plan-price">৳1,500</div><a href="/register" class="btn btn-purple" style="width:100%">Get Started</a></div>
<div class="price-card"><div class="plan-name">UNLIMITED</div><div class="plan-credits">&infin;</div><div class="plan-duration">lifetime access</div><div class="plan-price">৳5,000</div><a href="/register" class="btn btn-purple" style="width:100%">Get Started</a></div>
</div>
</section>

<section class="section" id="features">
<h2>Why DeveloperX?</h2>
<p class="subtitle">Everything you need for AI video creation in one place.</p>
<div class="features-grid">
<div class="feature-card"><h3>&#x1F3AC; All Models Unlocked</h3><p>Veo 3, Omni, Flash — all Google AI video models available with no restrictions.</p></div>
<div class="feature-card"><h3>&#x26A1; Instant Access</h3><p>Install extension, login, start generating. No complex setup required.</p></div>
<div class="feature-card"><h3>&#x1F510; Secure Sessions</h3><p>Managed Google Flow sessions with automatic cookie injection.</p></div>
<div class="feature-card"><h3>&#x1F4CA; Credit Tracking</h3><p>Real-time credit monitoring. See exactly how many generations you have left.</p></div>
<div class="feature-card"><h3>&#x1F4B0; Affordable Plans</h3><p>Starting from just ৳50/day. Flexible plans for every budget.</p></div>
<div class="feature-card"><h3>&#x1F4AC; 24/7 Support</h3><p>Direct Telegram/WhatsApp support. We are here when you need us.</p></div>
</div>
</section>

<section class="section">
<h2>How It Works</h2>
<p class="subtitle">Three simple steps to start creating AI videos.</p>
<div class="steps">
<div class="step"><div class="step-num">1</div><h3>Sign Up</h3><p>Create your account in seconds. Get 5 hours free trial.</p></div>
<div class="step"><div class="step-num">2</div><h3>Install Extension</h3><p>Add our Chrome extension with one click. Takes 30 seconds.</p></div>
<div class="step"><div class="step-num">3</div><h3>Generate Videos</h3><p>Open Google Flow and start creating unlimited AI videos.</p></div>
</div>
</section>

<section class="section">
<h2>Install Extension</h2>
<p class="subtitle">Download and install in under a minute.</p>
<div class="extension-box">
<h3>&#x1F4E6; DeveloperX Chrome Extension</h3>
<p style="color:var(--muted);font-size:13px;margin-bottom:16px">Powered by Google Flow Labs</p>
<ol style="margin-bottom:20px">
<li>Open <code style="background:var(--bg);padding:2px 6px;border-radius:4px">chrome://extensions</code></li>
<li>Enable <strong>Developer Mode</strong> (top right)</li>
<li>Click <strong>Load unpacked</strong></li>
<li>Select the extension folder we provide</li>
<li>Click the extension icon and sign in</li>
</ol>
<a href="https://t.me/DeveloperX" class="btn btn-gold" style="font-size:14px">&#x1F4AC; Contact on Telegram for Extension</a>
</div>
</section>

<footer>
<p>DeveloperX &copy; 2026. All rights reserved.</p>
<p style="margin-top:4px">Contact: Telegram @DeveloperX | developerx.bd@gmail.com</p>
</footer>
</div>
</body>
</html>`;

// ═══════════════════════════════════════════════════════════════
//  REGISTRATION PAGE
// ═══════════════════════════════════════════════════════════════
const REGISTER_HTML = `<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Sign Up — DeveloperX</title>
<style>
:root{--bg:#08090d;--card:#101217;--border:#1e2030;--text:#e4e6f0;--muted:#6b7084;--purple:#7c5cfc;--gold:#f0b90b;--green:#10b981;--red:#ef4444}
*{margin:0;padding:0;box-sizing:border-box}
body{font-family:system-ui,sans-serif;background:var(--bg);color:var(--text);display:flex;align-items:center;justify-content:center;min-height:100vh;padding:20px}
.form-box{background:var(--card);border:1px solid var(--border);border-radius:16px;padding:36px;width:100%;max-width:420px}
.form-box h1{font-size:24px;text-align:center;margin-bottom:4px}
.form-box .sub{text-align:center;color:var(--muted);font-size:13px;margin-bottom:24px}
label{display:block;font-size:12px;color:var(--muted);margin-bottom:4px;font-weight:600}
input,select{width:100%;padding:10px 12px;background:var(--bg);border:1px solid var(--border);border-radius:8px;color:var(--text);font-size:14px;margin-bottom:14px;outline:none;appearance:none}
input:focus,select:focus{border-color:var(--purple)}
select option{background:var(--card);color:var(--text)}
.btn{width:100%;padding:12px;border:none;border-radius:8px;font-weight:600;font-size:14px;cursor:pointer;transition:all .2s}
.btn-purple{background:var(--purple);color:#fff}
.btn-purple:hover{box-shadow:0 0 20px rgba(124,92,252,.3)}
.btn-gold{background:linear-gradient(135deg,var(--gold),#fbbf24);color:#000}
.msg{padding:8px;border-radius:6px;font-size:12px;text-align:center;margin:8px 0;display:none}
.msg-ok{background:rgba(16,185,129,.1);color:var(--green);display:block}
.msg-err{background:rgba(239,68,68,.1);color:var(--red);display:block}
.links{text-align:center;margin-top:16px;font-size:12px;color:var(--muted)}
.links a{color:var(--purple);text-decoration:none}
.plans{display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-bottom:16px}
.plan-opt{padding:10px;border:1px solid var(--border);border-radius:8px;text-align:center;cursor:pointer;font-size:12px;transition:all .2s}
.plan-opt:hover{border-color:var(--purple)}
.plan-opt.selected{border-color:var(--purple);background:rgba(124,92,252,.1)}
.plan-opt .name{font-weight:700;color:var(--purple);font-size:13px}
.plan-opt .info{color:var(--muted);font-size:11px}
</style>
</head>
<body>
<div class="form-box">
<h1>Create Account</h1>
<div class="sub">DeveloperX Unlimited Video Generation</div>
<div id="msgBox" class="msg"></div>
<form id="regForm" onsubmit="return handleRegister(event)">
<label>Email</label><input type="email" id="email" placeholder="your@email.com" required>
<label>Password</label><input type="password" id="password" placeholder="Min 6 characters" minlength="6" required>
<label>Select Plan</label>
<div class="plans" id="planSelector">
<div class="plan-opt" data-plan="trial" onclick="selectPlan(this)"><div class="name">5-HR TRIAL</div><div class="info">Free &#183; Unlimited credits</div></div>
<div class="plan-opt" data-plan="daily" onclick="selectPlan(this)"><div class="name">DAILY</div><div class="info">20 credits &#183; ৳50</div></div>
<div class="plan-opt" data-plan="weekly" onclick="selectPlan(this)"><div class="name">WEEKLY</div><div class="info">100 credits &#183; ৳200</div></div>
<div class="plan-opt" data-plan="monthly" onclick="selectPlan(this)"><div class="name">MONTHLY</div><div class="info">500 credits &#183; ৳500</div></div>
<div class="plan-opt" data-plan="pro" onclick="selectPlan(this)"><div class="name">PRO</div><div class="info">2000 credits &#183; ৳1500</div></div>
<div class="plan-opt" data-plan="unlimited" onclick="selectPlan(this)"><div class="name">UNLIMITED</div><div class="info">&infin; credits &#183; ৳5000</div></div>
</div>
<input type="hidden" id="selectedPlan" value="trial">
<button type="submit" class="btn btn-purple" id="regBtn">Create Account</button>
</form>
<div id="successBox" style="display:none;text-align:center;margin-top:16px">
<div style="font-size:40px;margin-bottom:8px">&#x2705;</div>
<h3>Account Created!</h3>
<p style="color:var(--muted);font-size:13px;margin:8px 0"><span id="successPlan"></span> plan activated</p>
<div style="background:var(--bg);padding:12px;border-radius:8px;margin:12px 0;text-align:left;font-size:12px">
<p><strong>Email:</strong> <span id="successEmail"></span></p>
<p><strong>Credits:</strong> <span id="successCredits"></span></p>
<p><strong>Trial:</strong> <span id="successTrial"></span></p>
</div>
<a href="/dashboard" class="btn btn-gold" style="display:block;text-align:center;padding:12px;margin-top:12px;text-decoration:none">Go to Dashboard</a>
</div>
<div class="links">Already have an account? <a href="/login">Login</a> &#183; <a href="/">Home</a></div>
</div>
<script>
var selectedPlan='trial';
function selectPlan(el){document.querySelectorAll('.plan-opt').forEach(function(c){c.classList.remove('selected')});el.classList.add('selected');selectedPlan=el.dataset.plan;document.getElementById('selectedPlan').value=selectedPlan;document.getElementById('msgBox').className='msg'}
document.querySelector('[data-plan="trial"]').classList.add('selected');
function msg(t,ok){var m=document.getElementById('msgBox');m.textContent=t;m.className='msg '+(ok?'msg-ok':'msg-err')}
async function handleRegister(e){e.preventDefault();var btn=document.getElementById('regBtn');btn.disabled=true;btn.textContent='Creating...';
var email=document.getElementById('email').value.trim();
var password=document.getElementById('password').value;
var plan=selectedPlan;
try{
var r=await fetch('/api/public/auth/register',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({email:email,password:password,plan:plan})});
var j=await r.json();
if(!r.ok)throw new Error(j.error||j.message||'Registration failed');
document.getElementById('regForm').style.display='none';
var s=document.getElementById('successBox');s.style.display='block';
document.getElementById('successPlan').textContent=j.user.plan||plan;
document.getElementById('successEmail').textContent=email;
document.getElementById('successCredits').textContent=j.user.creditsLeft+' credits';
document.getElementById('successTrial').textContent=j.user.trialHours?j.user.trialHours+' hours free trial':'Paid plan';
chrome&&chrome.storage&&chrome.storage.local.set({userId:j.user.id,userName:j.user.name,userPlan:j.user.plan||'ultra',plan:j.user.plan||'ultra',creditsLeft:j.user.creditsLeft,loggedIn:true,sessionToken:j.user.id+':'+email});
}catch(err){msg(err.message,false)}finally{btn.disabled=false;btn.textContent='Create Account'}
return false}
</script>
</body>
</html>`;

// ═══════════════════════════════════════════════════════════════
//  PUBLIC LOGIN PAGE
// ═══════════════════════════════════════════════════════════════
const LOGIN_HTML = `<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Login — DeveloperX</title>
<style>
:root{--bg:#08090d;--card:#101217;--border:#1e2030;--text:#e4e6f0;--muted:#6b7084;--purple:#7c5cfc;--gold:#f0b90b;--green:#10b981;--red:#ef4444}
*{margin:0;padding:0;box-sizing:border-box}
body{font-family:system-ui,sans-serif;background:var(--bg);color:var(--text);display:flex;align-items:center;justify-content:center;min-height:100vh;padding:20px}
.login-box{background:var(--card);border:1px solid var(--border);border-radius:16px;padding:36px;width:100%;max-width:400px}
.login-box h1{font-size:24px;text-align:center;margin-bottom:4px}
.login-box .sub{text-align:center;color:var(--muted);font-size:13px;margin-bottom:24px}
label{display:block;font-size:12px;color:var(--muted);margin-bottom:4px;font-weight:600}
input{width:100%;padding:10px 12px;background:var(--bg);border:1px solid var(--border);border-radius:8px;color:var(--text);font-size:14px;margin-bottom:14px;outline:none}
input:focus{border-color:var(--purple)}
.btn{width:100%;padding:12px;border:none;border-radius:8px;font-weight:600;font-size:14px;cursor:pointer}
.btn-purple{background:var(--purple);color:#fff}
.msg{padding:8px;border-radius:6px;font-size:12px;text-align:center;margin:8px 0;display:none}
.msg-err{background:rgba(239,68,68,.1);color:var(--red);display:block}
.msg-ok{background:rgba(16,185,129,.1);color:var(--green);display:block}
.links{text-align:center;margin-top:16px;font-size:12px;color:var(--muted)}
.links a{color:var(--purple);text-decoration:none}
.dash{display:none;text-align:center}
.dash .plan-badge{display:inline-block;padding:4px 12px;border-radius:12px;font-size:11px;font-weight:700;background:rgba(124,92,252,.2);color:var(--purple);margin-bottom:8px}
.dash .credits{font-size:36px;font-weight:800;color:var(--gold)}
.dash .meta{font-size:13px;color:var(--muted);margin:4px 0}
</style>
</head>
<body>
<div class="login-box">
<h1>Login</h1>
<div class="sub">Access your DeveloperX account</div>
<div id="msgBox" class="msg"></div>
<div id="loginForm">
<form onsubmit="return handleLogin(event)">
<label>Email</label><input type="email" id="email" placeholder="your@email.com" required>
<label>Password</label><input type="password" id="password" placeholder="Password" required>
<button type="submit" class="btn btn-purple" id="loginBtn">Sign In</button>
</form>
<div class="links">No account? <a href="/register">Create one</a> &#183; <a href="/">Home</a></div>
</div>
<div id="dashPanel" class="dash">
<div class="plan-badge" id="planBadge">PLAN</div>
<h2>Welcome, <span id="userName"></span></h2>
<div class="credits" id="creditsLeft">0</div>
<div class="meta">credits remaining</div>
<div class="meta">Expires: <span id="expires">—</span></div>
<div class="meta" id="trialInfo" style="color:var(--gold);margin-top:4px"></div>
<div style="margin-top:20px;background:var(--bg);border:1px solid var(--border);border-radius:10px;padding:16px;text-align:left;font-size:12px">
<h4 style="margin-bottom:8px">&#x1F4E6; Install Extension</h4>
<ol style="color:var(--muted);padding-left:16px;line-height:1.8">
<li>Open <code style="background:var(--card);padding:1px 4px;border-radius:3px">chrome://extensions</code></li>
<li>Enable Developer Mode</li>
<li>Click <strong>Load unpacked</strong></li>
<li>Select the DeveloperX extension folder</li>
<li>Login with same email/password</li>
</ol>
</div>
<button class="btn btn-purple" style="margin-top:16px" onclick="location.href='/dashboard'">&#x1F4CA; Full Dashboard</button>
</div>
</div>
<script>
function msg(t,ok){var m=document.getElementById('msgBox');m.textContent=t;m.className='msg '+(ok?'msg-ok':'msg-err')}
async function handleLogin(e){e.preventDefault();
var btn=document.getElementById('loginBtn');btn.disabled=true;btn.textContent='Signing in...';
var email=document.getElementById('email').value.trim();
var password=document.getElementById('password').value;
try{
var r=await fetch('/api/public/auth/login',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({email:email,password:password})});
var j=await r.json();
if(!r.ok||!j.user)throw new Error(j.message||'Login failed');
document.getElementById('loginForm').style.display='none';
var d=document.getElementById('dashPanel');d.style.display='block';
document.getElementById('planBadge').textContent=(j.user.plan||'trial').toUpperCase();
document.getElementById('userName').textContent=j.user.name||email;
document.getElementById('creditsLeft').textContent=j.user.creditsLeft!=null?j.user.creditsLeft:'&infin;';
document.getElementById('expires').textContent=j.user.expiresAt?new Date(j.user.expiresAt).toLocaleDateString():'Never';
if(j.user.trialHours){document.getElementById('trialInfo').textContent='Trial: '+j.user.trialHours+' hours from signup'}
chrome&&chrome.storage&&chrome.storage.local.set({userId:j.user.id,userName:j.user.name,userPlan:j.user.plan||'ultra',plan:j.user.plan||'ultra',creditsLeft:j.user.creditsLeft,expiresAt:j.user.expiresAt,loggedIn:true,sessionToken:j.user.id+':'+email});
}catch(err){msg(err.message,false)}
btn.disabled=false;btn.textContent='Sign In';return false}
</script>
</body>
</html>`;

// ═══════════════════════════════════════════════════════════════
//  USER DASHBOARD PAGE
// ═══════════════════════════════════════════════════════════════
const DASHBOARD_HTML = `// ═══════════════════════════════════════════════════════════════
//  DASHBOARD HTML — DeveloperX Premium Design
// ═══════════════════════════════════════════════════════════════
const DASHBOARD_HTML = \`<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Dashboard — DeveloperX</title>
<style>
:root{--bg:#020617;--card:#0f172a;--border:rgba(255,255,255,.08);--text:#e2e8f0;--muted:#94a3b8;--purple:#818cf8;--gold:#f59e0b;--green:#10b981;--red:#ef4444;--cyan:#22d3ee}
*{margin:0;padding:0;box-sizing:border-box}
body{font-family:'Outfit',system-ui,sans-serif;background:var(--bg);color:var(--text);min-height:100vh;overflow-x:hidden}
.ambient{position:fixed;inset:0;pointer-events:none;z-index:-1}
.ambient::before{content:'';position:absolute;top:-10%;left:-10%;width:50%;height:50%;background:radial-gradient(circle,rgba(99,102,241,.25),transparent 70%)}
.ambient::after{content:'';position:absolute;bottom:-10%;right:-10%;width:50%;height:50%;background:radial-gradient(circle,rgba(34,211,238,.12),transparent 70%)}
.container{max-width:960px;margin:0 auto;padding:24px 20px}
nav{display:flex;justify-content:space-between;align-items:center;padding:18px 24px;margin-bottom:32px;border-radius:16px;border:1px solid var(--border);background:rgba(15,23,42,.8);backdrop-filter:blur(20px)}
.logo{font-size:22px;font-weight:800;background:linear-gradient(135deg,var(--purple),var(--cyan));-webkit-background-clip:text;-webkit-text-fill-color:transparent}
.nav-links{display:flex;gap:24px;font-size:13px}
.nav-links a{color:var(--muted);text-decoration:none;transition:color .2s}
.nav-links a:hover{color:#fff}
.status-cards{display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:14px;margin-bottom:28px}
.stat-card{background:linear-gradient(135deg,rgba(15,23,42,.9),rgba(30,41,59,.6));border:1px solid var(--border);border-radius:16px;padding:22px 20px;backdrop-filter:blur(12px)}
.stat-card .label{font-size:11px;color:var(--muted);text-transform:uppercase;letter-spacing:.8px;margin-bottom:6px}
.stat-card .value{font-size:28px;font-weight:800}
.stat-card .value.gold{color:var(--gold)}
.stat-card .value.green{color:var(--green)}
.stat-card .value.purple{background:linear-gradient(135deg,var(--purple),var(--cyan));-webkit-background-clip:text;-webkit-text-fill-color:transparent}
.main-card{background:linear-gradient(135deg,rgba(15,23,42,.95),rgba(30,41,59,.5));border:1px solid var(--border);border-radius:16px;padding:28px;margin-bottom:16px;backdrop-filter:blur(12px)}
.main-card h2{font-size:18px;margin-bottom:14px;display:flex;align-items:center;gap:10px}
.badge{display:inline-block;padding:4px 12px;border-radius:20px;font-size:10px;font-weight:700;background:rgba(129,140,248,.18);color:var(--purple);letter-spacing:.5px}
.pbar{width:100%;height:6px;background:rgba(255,255,255,.08);border-radius:3px;margin-top:14px;overflow:hidden}
.pbar-fill{height:100%;border-radius:3px;background:linear-gradient(90deg,var(--purple),var(--cyan));transition:width .5s}
.extension-steps{background:rgba(0,0,0,.2);border:1px solid var(--border);border-radius:12px;padding:20px 20px 20px 36px;margin-top:14px}
.extension-steps ol{color:var(--muted);font-size:13px;line-height:2.2}
.extension-steps code{background:rgba(129,140,248,.15);color:var(--purple);padding:2px 6px;border-radius:4px;font-size:12px}
.btn{padding:11px 22px;border-radius:10px;font-weight:600;font-size:13px;cursor:pointer;border:none;text-decoration:none;display:inline-block;margin-top:10px;transition:all .2s}
.btn-purple{background:linear-gradient(135deg,var(--purple),#6366f1);color:#fff;box-shadow:0 4px 20px rgba(129,140,248,.3)}
.btn-purple:hover{transform:translateY(-1px);box-shadow:0 6px 30px rgba(129,140,248,.4)}
.btn-gold{background:linear-gradient(135deg,var(--gold),#d97706);color:#000;font-weight:700;box-shadow:0 4px 20px rgba(245,158,11,.25)}
.btn-gold:hover{transform:translateY(-1px)}
.btn-outline{border:1px solid var(--border);color:var(--text);background:transparent}
.btn-outline:hover{background:rgba(255,255,255,.05)}
.btn-group{display:flex;gap:10px;flex-wrap:wrap}
.alert{padding:14px 18px;border-radius:10px;font-size:13px;margin-bottom:18px}
.alert-warn{background:rgba(245,158,11,.1);border:1px solid rgba(245,158,11,.25);color:#fbbf24}
.alert-err{background:rgba(239,68,68,.1);border:1px solid rgba(239,68,68,.25);color:var(--red)}
.alert-info{background:rgba(34,211,238,.08);border:1px solid rgba(34,211,238,.2);color:#22d3ee}
.login-prompt{max-width:440px;margin:60px auto;background:linear-gradient(135deg,rgba(15,23,42,.95),rgba(30,41,59,.7));border:1px solid var(--border);border-radius:20px;padding:40px 32px;text-align:center;backdrop-filter:blur(20px)}
.login-prompt h2{font-size:24px;margin-bottom:8px}
.login-prompt p{color:var(--muted);font-size:13px;margin-bottom:22px}
.login-prompt input{width:100%;padding:12px 16px;background:rgba(0,0,0,.3);border:1px solid var(--border);border-radius:10px;color:var(--text);font-size:14px;margin-bottom:12px;outline:none;transition:border .2s}
.login-prompt input:focus{border-color:var(--purple)}
.login-prompt .btn{width:100%}
footer{text-align:center;padding:32px 0;color:var(--muted);font-size:11px;border-top:1px solid var(--border);margin-top:48px}
.fade-in{animation:fadeIn .5s ease}
@keyframes fadeIn{from{opacity:0;transform:translateY(8px)}to{opacity:1;transform:translateY(0)}}
</style>
</head>
<body>
<div class="ambient"></div>
<div class="container">
<nav>
<div class="logo">DeveloperX</div>
<div class="nav-links">
<a href="/">Home</a>
<a href="#" onclick="doLogout()">Logout</a>
</div>
</nav>

<div id="loginPrompt" class="login-prompt">
<h2>Welcome Back</h2>
<p>Sign in to access your dashboard</p>
<input type="email" id="email" placeholder="Email" value="">
<input type="password" id="password" placeholder="Password">
<button class="btn btn-purple" id="dashLoginBtn" onclick="dashLogin()">Sign In</button>
<div id="loginMsg" style="font-size:12px;margin-top:10px"></div>
</div>

<div id="dashContent" style="display:none">
<div id="blockedAlert" class="alert alert-err" style="display:none"><strong>⚠️ Account Blocked:</strong> <span id="blockReason"></span><br><small>Contact DeveloperX to upgrade.</small></div>
<div id="trialAlert" class="alert alert-info" style="display:none"><strong>⏳ <span id="trialText"></span></strong><br><small>Upgrade to keep access after trial ends.</small></div>

<div class="status-cards">
<div class="stat-card"><div class="label">Plan</div><div class="value purple"><span id="planDisp">—</span></div></div>
<div class="stat-card"><div class="label">Minutes Left</div><div class="value gold" id="timeDisp">—</div></div>
<div class="stat-card"><div class="label">Used</div><div class="value" id="usedDisp">—</div></div>
<div class="stat-card"><div class="label">Status</div><div class="value green" id="statusDisp">Active</div></div>
</div>

<div class="main-card fade-in">
<h2>👋 Welcome, <span id="userNameDisp">—</span> <span class="badge" id="planBadge">PLAN</span></h2>
<div style="color:var(--muted);font-size:13px;margin-bottom:10px">Expires: <span id="expiryDisp">—</span></div>
<div class="pbar"><div class="pbar-fill" id="pbarFill" style="width:0%"></div></div>
<div style="margin-top:18px;font-size:12px;color:var(--muted)"><span id="pctUsed">0%</span> used</div>
<div class="btn-group" style="margin-top:18px">
<button class="btn btn-gold" onclick="alert('Contact @DeveloperX on Telegram to upgrade!')">⬆ Upgrade Plan</button>
<button class="btn btn-outline" onclick="doLogout()">Sign Out</button>
</div>
</div>

<div class="main-card">
<h2>📦 DeveloperX Extension</h2>
<div class="extension-steps">
<ol>
<li>Open <code>chrome://extensions</code> in Chrome</li>
<li>Enable <strong>Developer Mode</strong> (toggle top right)</li>
<li>Click <strong>"Load unpacked"</strong></li>
<li>Select the <strong>extension</strong> folder</li>
<li>Open extension → login → <strong>Open Flow</strong></li>
<li>Start generating videos!</li>
</ol>
</div>
<button class="btn btn-purple" onclick="alert('Contact @DeveloperX on Telegram to get the extension!')">📥 Get Extension</button>
</div>

<footer>DeveloperX &copy; 2026 · Made with ❤️</footer>
</div>
</div>

<script>
const API='';
function getDashboardToken(){try{return localStorage.getItem('dx_token')}catch{return null}}
function setDashboardToken(t){try{localStorage.setItem('dx_token',t)}catch{}}
function clearDashboardToken(){try{localStorage.removeItem('dx_token')}catch{}}

async function dashLogin(){
var email=document.getElementById('email').value.trim()||'user@dx.dev';
var pw=document.getElementById("password").value||"pass";
var m=document.getElementById('loginMsg'),btn=document.getElementById('dashLoginBtn');
btn.disabled=true;btn.textContent='Signing in...';
try{
var r=await fetch(API+'/api/public/auth/login',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({email:email,password:pass})});
var j=await r.json();
if(!r.ok||!j.user)throw new Error(j.message||'Login failed');
setDashboardToken(j.user.id+':'+email);
showDash(j.user);
}catch(e){m.style.color='var(--red)';m.textContent=e.message}
btn.disabled=false;btn.textContent='Sign In';
}

function showDash(user){
document.getElementById('loginPrompt').style.display='none';
document.getElementById('dashContent').style.display='block';
document.getElementById('userNameDisp').textContent=user.name||user.email;
document.getElementById('planDisp').textContent=(user.plan||'trial').toUpperCase();
document.getElementById('planBadge').textContent=(user.plan||'trial').toUpperCase();
document.getElementById('timeDisp').textContent=user.remainingTimeStr||(user.remainingTime+'m');
document.getElementById('usedDisp').textContent=user.usedTimeStr||(user.usedTime+'m');
document.getElementById('expiryDisp').textContent=user.expiresAt?new Date(user.expiresAt).toLocaleDateString():'Never';

// Progress bar
var total=user.totalTime||user.remainingTime||1;
var used=user.usedTime||0;
var pct=Math.min(100,Math.round(used/total*100));
document.getElementById('pbarFill').style.width=pct+'%';
document.getElementById('pctUsed').textContent=pct+'%';

if(user.blocked){
document.getElementById('blockedAlert').style.display='block';
document.getElementById('blockReason').textContent=user.blockReason||'Contact admin';
document.getElementById('statusDisp').textContent='Blocked';
document.getElementById('statusDisp').style.color='var(--red)';
}
if(user.plan==='trial'){
document.getElementById('trialAlert').style.display='block';
document.getElementById('trialText').textContent='Trial · '+(user.remainingTimeStr||'5h 0m')+' remaining';
}
}

function doLogout(){
clearDashboardToken();
document.getElementById('loginPrompt').style.display='block';
document.getElementById('dashContent').style.display='none';
document.getElementById('email').value='';
document.getElementById('password').value='';
document.getElementById('loginMsg').textContent='';
}

// Auto-login if token exists
var tok=getDashboardToken();
if(tok){
var uid=tok.split(':')[0];
fetch(API+'/api/verify?userId='+encodeURIComponent(uid))
.then(function(r){return r.json()})
.then(function(j){if(j.user)showDash(j.user);else doLogout()})
.catch(function(){doLogout()});
}

// URL params auto-fill
var sp=new URLSearchParams(window.location.search);
if(sp.get('email')){document.getElementById('email').value=sp.get('email');if(sp.get('pass')){document.getElementById('password').value=sp.get('pass');setTimeout(dashLogin,500)}}
</script>
</body>
</html>\`;
`;

const ADMIN_HTML = `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>DeveloperX — Admin Dashboard</title>
  <style>
    :root {
      --bg: #08090d;
      --card-bg: #101217;
      --border: #1e2030;
      --text: #e4e6f0;
      --muted: #6b7084;
      --accent: #7c5cfc;
      --accent-glow: #7c5cfc44;
      --green: #10b981;
      --red: #ef4444;
      --amber: #f59e0b;
      --blue: #3b82f6;
      --radius: 12px;
      --radius-sm: 8px;
    }
    *,*::before,*::after { box-sizing: border-box; margin: 0; padding: 0; }
    body {
      font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
      background: var(--bg);
      color: var(--text);
      min-height: 100vh;
      line-height: 1.5;
    }

    /* ── Layout ── */
    .container { max-width: 1400px; margin: 0 auto; padding: 24px 20px 60px; }

    /* ── Header ── */
    .header {
      display: flex; align-items: center; justify-content: space-between;
      flex-wrap: wrap; gap: 16px; margin-bottom: 28px;
      padding-bottom: 20px; border-bottom: 1px solid var(--border);
    }
    .header-brand { display: flex; align-items: center; gap: 12px; }
    .header-logo {
      width: 40px; height: 40px; border-radius: var(--radius-sm);
      background: linear-gradient(135deg, #7c5cfc, #a78bfa);
      display: flex; align-items: center; justify-content: center;
      font-size: 20px; font-weight: 800; color: #fff;
    }
    .header-title { font-size: 22px; font-weight: 700; letter-spacing: -0.3px; }
    .header-sub { font-size: 12px; color: var(--muted); }

    .login-box { display: flex; gap: 8px; align-items: center; }
    .login-box input {
      background: var(--card-bg); border: 1px solid var(--border);
      color: var(--text); padding: 8px 14px; border-radius: var(--radius-sm);
      font-size: 13px; width: 180px; outline: none;
      transition: border-color 0.2s;
    }
    .login-box input:focus { border-color: var(--accent); }

    /* ── Buttons ── */
    .btn {
      display: inline-flex; align-items: center; gap: 6px;
      padding: 8px 18px; border-radius: 99px; font-size: 13px; font-weight: 600;
      cursor: pointer; border: none; transition: all 0.2s;
      white-space: nowrap;
    }
    .btn-primary { background: var(--accent); color: #fff; }
    .btn-primary:hover { background: #6d4ff7; box-shadow: 0 0 20px var(--accent-glow); }
    .btn-danger { background: var(--red); color: #fff; }
    .btn-danger:hover { background: #dc2626; }
    .btn-warning { background: var(--amber); color: #000; }
    .btn-warning:hover { background: #d97706; }
    .btn-green { background: var(--green); color: #000; }
    .btn-green:hover { background: #059669; }
    .btn-sm { padding: 5px 12px; font-size: 11px; }
    .btn-xs { padding: 3px 10px; font-size: 10px; }
    .btn-outline {
      background: transparent; border: 1px solid var(--border); color: var(--text);
    }
    .btn-outline:hover { border-color: var(--accent); background: var(--accent-glow); }

    /* ── Cards ── */
    .card {
      background: var(--card-bg); border: 1px solid var(--border);
      border-radius: var(--radius); padding: 20px; margin-bottom: 18px;
    }
    .card-header {
      font-size: 16px; font-weight: 700; margin-bottom: 16px;
      display: flex; align-items: center; gap: 8px;
    }

    /* ── Stats grid ── */
    .stats-grid {
      display: grid; grid-template-columns: repeat(auto-fill, minmax(180px, 1fr));
      gap: 14px; margin-bottom: 28px;
    }
    .stat-card {
      background: var(--card-bg); border: 1px solid var(--border);
      border-radius: var(--radius); padding: 18px;
    }
    .stat-label { font-size: 11px; text-transform: uppercase; color: var(--muted); letter-spacing: 0.5px; }
    .stat-value { font-size: 28px; font-weight: 800; margin-top: 4px; }
    .stat-accent { color: var(--accent); }
    .stat-green { color: var(--green); }
    .stat-red { color: var(--red); }
    .stat-amber { color: var(--amber); }

    /* ── Forms ── */
    .form-row {
      display: flex; gap: 10px; flex-wrap: wrap; align-items: flex-end;
    }
    .form-group { display: flex; flex-direction: column; gap: 4px; }
    .form-group label { font-size: 11px; color: var(--muted); text-transform: uppercase; }
    .form-group input, .form-group select {
      background: #000; border: 1px solid var(--border);
      color: var(--text); padding: 8px 12px; border-radius: var(--radius-sm);
      font-size: 13px; outline: none; width: 100%;
      transition: border-color 0.2s;
    }
    .form-group input:focus, .form-group select:focus { border-color: var(--accent); }
    .form-group input[type=number] { -moz-appearance: textfield; }
    .w-80 { width: 80px; } .w-100 { width: 100px; }
    .w-140 { width: 140px; } .w-180 { width: 180px; }

    /* ── Tables ── */
    .table-wrap { overflow-x: auto; }
    table { width: 100%; border-collapse: collapse; font-size: 13px; }
    thead th {
      text-align: left; padding: 10px 12px; background: #0a0b10;
      color: var(--muted); font-size: 10px; text-transform: uppercase;
      letter-spacing: 0.5px; position: sticky; top: 0; border-bottom: 1px solid var(--border);
    }
    tbody td { padding: 10px 12px; border-bottom: 1px solid #1a1c28; }
    tbody tr:hover { background: #1a1c2833; }
    .mono { font-family: 'JetBrains Mono', 'Fira Code', monospace; font-size: 11px; }

    /* ── Badges ── */
    .badge {
      display: inline-block; padding: 2px 10px; border-radius: 99px;
      font-size: 10px; font-weight: 700; text-transform: uppercase;
    }
    .badge-active { background: #10b98122; color: var(--green); }
    .badge-expired { background: #ef444422; color: var(--red); }
    .badge-disabled { background: #6b728022; color: var(--muted); }
    .badge-trial { background: #7c5cfc22; color: var(--accent); }
    .badge-pro { background: #3b82f622; color: var(--blue); }

    /* ── Modal ── */
    .modal-overlay {
      display: none; position: fixed; inset: 0; background: #000000aa;
      z-index: 100; align-items: center; justify-content: center;
    }
    .modal-overlay.open { display: flex; }
    .modal {
      background: var(--card-bg); border: 1px solid var(--border);
      border-radius: var(--radius); padding: 28px; max-width: 520px; width: 95%;
      max-height: 90vh; overflow-y: auto;
    }
    .modal h3 { font-size: 18px; margin-bottom: 20px; }
    .modal .form-group { margin-bottom: 14px; }
    .modal .form-group label { margin-bottom: 4px; }
    .modal-actions { display: flex; gap: 8px; justify-content: flex-end; margin-top: 24px; }

    /* ── Toast ── */
    .toast {
      position: fixed; bottom: 24px; left: 50%; transform: translateX(-50%);
      background: var(--card-bg); border: 1px solid var(--border);
      padding: 10px 24px; border-radius: 99px; font-size: 13px;
      display: none; z-index: 200; white-space: nowrap;
    }

    /* ── Code blocks ── */
    pre.code-block {
      background: #000; padding: 14px; border-radius: var(--radius-sm);
      font-size: 11px; font-family: 'JetBrains Mono', 'Fira Code', monospace;
      color: #a5d6ff; max-height: 320px; overflow: auto;
      border: 1px solid var(--border);
    }

    /* ── Footer ── */
    .footer {
      text-align: center; font-size: 11px; color: var(--muted);
      margin-top: 40px; padding-top: 20px; border-top: 1px solid var(--border);
    }

    /* ── Responsive ── */
    @media (max-width: 768px) {
      .header { flex-direction: column; align-items: flex-start; }
      .stats-grid { grid-template-columns: repeat(2, 1fr); }
      .form-row { flex-direction: column; }
    }
    @media (max-width: 480px) {
      .stats-grid { grid-template-columns: 1fr; }
      .login-box input { width: 120px; }
    }

    /* ── Section visibility ── */
    .hidden { display: none !important; }
  </style>
</head>
<body>
<div class="container">

  <!-- Header -->
  <div class="header">
    <div class="header-brand">
      <div class="header-logo">DX</div>
      <div>
        <div class="header-title">DeveloperX Admin</div>
        <div class="header-sub">Subscription &amp; Credit Management</div>
      </div>
    </div>
    <div class="login-box">
      <input type="password" id="adminKey" placeholder="Admin Key" onkeydown="if(event.key==='Enter')login()">
      <button class="btn btn-primary" onclick="login()">🔐 Login</button>
    </div>
  </div>

  <!-- Main panel (hidden until login) -->
  <div id="mainPanel" class="hidden">

    <!-- Stats Dashboard -->
    <div class="card-header" style="margin-top:0">📊 Dashboard</div>
    <div class="stats-grid" id="statsGrid">
      <div class="stat-card"><div class="stat-label">Total Users</div><div class="stat-value stat-accent" id="statTotal">-</div></div>
      <div class="stat-card"><div class="stat-label">Active</div><div class="stat-value stat-green" id="statActive">-</div></div>
      <div class="stat-card"><div class="stat-label">Expired</div><div class="stat-value stat-red" id="statExpired">-</div></div>
      <div class="stat-card"><div class="stat-label">Trial Users</div><div class="stat-value stat-accent" id="statTrial">-</div></div>
      <div class="stat-card"><div class="stat-label">Disabled</div><div class="stat-value stat-amber" id="statDisabled">-</div></div>
      <div class="stat-card"><div class="stat-label">Credits Used</div><div class="stat-value stat-amber" id="statCredits">-</div></div>
    </div>

    <!-- Create User -->
    <div class="card">
      <div class="card-header">➕ Create User</div>
      <div class="form-row">
        <div class="form-group"><label>Email</label><input id="fEmail" placeholder="user@domain.com" class="w-180"></div>
        <div class="form-group"><label>Password</label><input id="fPass" type="text" placeholder="min 6 chars" class="w-140"></div>
        <div class="form-group"><label>Display Name</label><input id="fName" placeholder="User" class="w-140"></div>
        <div class="form-group"><label>Plan</label>
          <select id="fPlan" class="w-100"><option value="trial">Trial</option><option value="pro">Pro</option><option value="ultra">Ultra</option><option value="basic">Basic</option></select></div>
        <div class="form-group"><label>Credits</label><input id="fCredits" type="number" value="0" placeholder="0=∞" class="w-80"></div>
        <div class="form-group"><label>Daily Limit</label><input id="fDaily" type="number" value="0" placeholder="0=∞" class="w-80"></div>
        <div class="form-group"><label>Expires (days)</label><input id="fExpiry" type="number" value="30" class="w-80"></div>
        <div class="form-group"><label>Trial Hours</label><input id="fTrialH" type="number" value="5" class="w-80"></div>
        <div style="display:flex;align-items:flex-end"><button class="btn btn-primary" onclick="createUser()">Create</button></div>
      </div>
      <div id="createMsg" style="margin-top:10px;font-size:13px"></div>
    </div>

    <!-- Bulk Create -->
    <div class="card">
      <div class="card-header">💾 Bulk Generate Users</div>
      <div class="form-row">
        <div class="form-group"><label>Count</label><input id="bulkCount" type="number" value="10" class="w-80"></div>
        <div class="form-group"><label>Domain</label><input id="bulkDomain" value="flowmail.local" class="w-140"></div>
        <div class="form-group"><label>Credits</label><input id="bulkCredits" type="number" value="1000" class="w-80"></div>
        <div class="form-group"><label>Days</label><input id="bulkDays" type="number" value="30" class="w-80"></div>
        <div style="display:flex;align-items:flex-end;gap:8px">
          <button class="btn btn-primary" onclick="bulkCreate()">Generate</button>
          <button class="btn btn-outline btn-sm hidden" id="dlBtn" onclick="downloadBulk()">📥 Download .txt</button>
        </div>
      </div>
      <pre class="code-block hidden" id="bulkResult" style="margin-top:14px"></pre>
    </div>

    <!-- Users Table -->
    <div class="card">
      <div class="card-header" style="justify-content:space-between">
        <span>👥 Users</span>
        <button class="btn btn-outline btn-sm" onclick="loadAll()">🔄 Refresh</button>
      </div>
      <div class="table-wrap">
        <table>
          <thead>
            <tr>
              <th>Email</th><th>Name</th><th>Plan</th>
              <th>Time Used / Total</th>
              <th>Trial</th><th>Status</th><th>Expires</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody id="usersTbody"></tbody>
        </table>
      </div>
    </div>

    <!-- Global Cookies -->
    <div class="card">
      <div class="card-header" style="justify-content:space-between">
        <span>🍪 Global Cookies</span>
        <div style="display:flex;gap:8px">
          <button class="btn btn-outline btn-sm" onclick="fetchLiveCookies(this)" style="background:#7c5cfc;color:#fff;border:none">⚡ Fetch Live</button>
          <button class="btn btn-outline btn-sm" onclick="toggleCookieUpload()">📤 Update</button>
        </div>
      </div>
      <div id="cookieCount" style="font-size:13px;margin-bottom:8px"></div>
      <div id="cookieUpload" class="hidden" style="margin-top:12px">
        <textarea id="cookieJson" style="width:100%;height:130px;background:#000;color:#a5d6ff;border:1px solid var(--border);padding:12px;font-size:12px;border-radius:var(--radius-sm);font-family:monospace;resize:vertical" placeholder="Paste cookie JSON array here..."></textarea>
        <button class="btn btn-primary" onclick="uploadCookies()" style="margin-top:8px">Upload Cookies</button>
      </div>
    </div>

    <!-- Credit Ledger -->
    <div class="card">
      <div class="card-header">📊 Credit Ledger</div>
      <div class="table-wrap">
        <table>
          <thead><tr><th>Time</th><th>User</th><th>Amount</th><th>Balance After</th><th>Reason</th></tr></thead>
          <tbody id="ledgerTbody"></tbody>
        </table>
      </div>
    </div>

    <!-- Footer -->
    <div class="footer">
      DeveloperX &copy; 2026 — Built for creators. All rights reserved.
    </div>
  </div>
</div>

<!-- Edit User Modal -->
<div class="modal-overlay" id="editModal">
  <div class="modal">
    <h3>✏️ Edit User</h3>
    <input type="hidden" id="editUserId">
    <div class="form-group"><label>Display Name</label><input id="editName"></div>
    <div class="form-group"><label>Email</label><input id="editEmail" disabled style="opacity:.5"></div>
    <div class="form-group"><label>Plan</label>
      <select id="editPlan"><option value="trial">Trial</option><option value="pro">Pro</option><option value="ultra">Ultra</option><option value="basic">Basic</option></select></div>
    <div class="form-row">
      <div class="form-group"><label>Credit Limit</label><input id="editCredits" type="number" placeholder="0 = unlimited"></div>
      <div class="form-group"><label>Credits Used</label><input id="editCreditsUsed" type="number"></div>
    </div>
    <div class="form-row">
      <div class="form-group"><label>Daily Limit</label><input id="editDaily" type="number" placeholder="0 = none"></div>
      <div class="form-group"><label>Trial Hours</label><input id="editTrialH" type="number"></div>
    </div>
    <div class="form-row">
      <div class="form-group"><label>Trial Used</label>
        <select id="editTrialUsed"><option value="false">No</option><option value="true">Yes</option></select></div>
      <div class="form-group"><label>Disabled</label>
        <select id="editDisabled"><option value="false">No</option><option value="true">Yes</option></select></div>
    </div>
    <div class="form-group"><label>Expires At (ISO)</label><input id="editExpires" placeholder="YYYY-MM-DDTHH:mm:ss.sssZ or empty"></div>
    <div class="modal-actions">
      <button class="btn btn-outline" onclick="closeModal()">Cancel</button>
      <button class="btn btn-primary" onclick="saveEdit()">Save Changes</button>
    </div>
  </div>
</div>

<!-- Toast -->
<div class="toast" id="toast"></div>

<script>
  let adminKey = '';
  let lastBulk = [];
  let allUsers = [];

  // ── Toast ──
  function toast(msg) {
    const t = document.getElementById('toast');
    t.textContent = msg;
    t.style.display = 'block';
    clearTimeout(t._timeout);
    t._timeout = setTimeout(() => t.style.display = 'none', 2800);
  }

  // ── API helper ──
  async function api(path, opts = {}) {
    const headers = { 'Content-Type': 'application/json' };
    if (adminKey) headers['X-Admin-Key'] = adminKey;
    const res = await fetch(path, { ...opts, headers: { ...headers, ...opts.headers } });
    return res.json();
  }

  // ── Login ──
  async function login() {
    const key = document.getElementById('adminKey').value.trim();
    if (!key) return toast('Enter admin key');
    const r = await fetch('/admin/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ key })
    }).then(r => r.json());

    if (r.ok) {
      adminKey = key;
      document.getElementById('mainPanel').classList.remove('hidden');
      toast('✅ Authenticated — Welcome to DeveloperX');
      loadAll();
    } else {
      toast('❌ Invalid admin key');
    }
  }

  // ── Load everything ──
  async function loadAll() {
    if (!adminKey) return;
    loadStats();
    loadUsers();
    loadLedger();
    listCookies();
  }

  // ── Stats ──
  async function loadStats() {
    const r = await api('/admin/stats');
    if (!r.totalUsers && r.totalUsers !== 0) return;
    document.getElementById('statTotal').textContent = r.totalUsers;
    document.getElementById('statActive').textContent = r.activeUsers;
    document.getElementById('statExpired').textContent = r.expiredUsers;
    document.getElementById('statDisabled').textContent = r.disabledUsers;
    document.getElementById('statTrial').textContent = r.trialUsers;
    document.getElementById('statCredits').textContent = r.totalCreditsUsed;
  }

  // ── Users table ──
  async function loadUsers() {
    const r = await api('/admin/users');
    if (!r.users) return;
    allUsers = r.users;
    const tbody = document.getElementById('usersTbody');
    tbody.innerHTML = '';

    r.users.forEach(u => {
      const now = new Date();
      const expiresAt = u.expires_at ? new Date(u.expires_at) : null;
      const isExpired = expiresAt && expiresAt < now;
      const isTrialActive = u.trial_hours > 0 && !u.trial_used;
      const trialExpired = isTrialActive && new Date(u.created_at).getTime() + u.trial_hours * 3600000 < now.getTime();
      const effectiveExpired = isExpired || trialExpired;

      const usedMins = u.minutes_used || 0;
      const totalMins = (u.credit_hours || 0) * 60 + (u.credit_minutes || 0);
      const usedStr = Math.floor(usedMins/60)+'h '+(usedMins%60)+'m';
      const totalStr = Math.floor(totalMins/60)+'h '+(totalMins%60)+'m';

      const statusBadge = u.disabled
        ? '<span class="badge badge-disabled">Disabled</span>'
        : effectiveExpired
          ? '<span class="badge badge-expired">Expired</span>'
          : '<span class="badge badge-active">Active</span>';

      const planBadge = u.plan === 'trial'
        ? '<span class="badge badge-trial">Trial</span>'
        : u.plan === 'pro' || u.plan === 'ultra'
          ? '<span class="badge badge-pro">' + u.plan.toUpperCase() + '</span>'
          : '<span class="badge">' + u.plan + '</span>';

      const trialInfo = isTrialActive
        ? '<span class="badge badge-trial">' + u.trial_hours + 'h active</span>'
        : u.trial_used
          ? '<span style="color:var(--muted);font-size:11px">used</span>'
          : '<span style="color:var(--muted);font-size:11px">none</span>';

      const tr = document.createElement('tr');
      tr.innerHTML =
        '<td><span class="mono">' + esc(u.email) + '</span></td>' +
        '<td>' + esc(u.display_name) + '</td>' +
        '<td>' + planBadge + '</td>' +
        '<td>' + usedStr + ' / ' + totalStr + '</td>' +
        '<td>' + trialInfo + '</td>' +
        '<td>' + statusBadge + '</td>' +
        '<td style="font-size:11px">' + (u.expires_at ? new Date(u.expires_at).toLocaleDateString() : '—') + '</td>' +
        '<td style="white-space:nowrap">' +
          '<button class="btn btn-outline btn-xs" onclick="openEdit(\\'' + u.user_id + '\\')" title="Edit">✏️</button> ' +
          '<button class="btn btn-warning btn-xs" onclick="resetCredits(\\'' + u.user_id + '\\')" title="Reset Credits">↺</button> ' +
          (u.disabled
            ? '<button class="btn btn-green btn-xs" onclick="toggleUser(\\'' + u.user_id + '\\')" title="Enable">▶</button>'
            : '<button class="btn btn-outline btn-xs" onclick="toggleUser(\\'' + u.user_id + '\\')" title="Disable">⏸</button>') +
          ' <button class="btn btn-danger btn-xs" onclick="deleteUser(\\'' + u.user_id + '\\')" title="Delete">🗑</button>' +
        '</td>';
      tbody.appendChild(tr);
    });
  }

  function esc(s) { return (s||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;'); }

  // ── Create user ──
  async function createUser() {
    const email = document.getElementById('fEmail').value.trim();
    const password = document.getElementById('fPass').value;
    if (!email || !password) return toast('Email and password required');

    const r = await api('/admin/users/create', {
      method: 'POST',
      body: JSON.stringify({
        email,
        password,
        display_name: document.getElementById('fName').value.trim(),
        plan: document.getElementById('fPlan').value,
        credit_hours: Number(document.getElementById('fHours').value) || 5,
        credit_minutes: Number(document.getElementById('fMinutes').value) || 0,
        expires_in_days: Number(document.getElementById('fExpiry').value) || 30,
        trial_hours: Number(document.getElementById('fTrialH').value),
      })
    });

    const msg = document.getElementById('createMsg');
    if (r.ok) {
      msg.innerHTML = '<span style="color:var(--green)">✅ Created: ' + esc(email) + ' / ' + esc(password) + '</span>';
      document.getElementById('fEmail').value = '';
      document.getElementById('fPass').value = '';
      loadAll();
    } else {
      msg.innerHTML = '<span style="color:var(--red)">❌ ' + esc(r.error) + '</span>';
    }
  }

  // ── Bulk create ──
  async function bulkCreate() {
    const count = Number(document.getElementById('bulkCount').value) || 10;
    const r = await api('/admin/users/bulk-create', {
      method: 'POST',
      body: JSON.stringify({
        count,
        domain: document.getElementById('bulkDomain').value,
        credits: Number(document.getElementById('bulkCredits').value),
        expires_in_days: Number(document.getElementById('bulkDays').value),
      })
    });
    lastBulk = r.results || [];
    const el = document.getElementById('bulkResult');
    el.classList.remove('hidden');
    el.textContent = lastBulk.map(u => u.ok ? u.email + ':' + u.password : u.email + ' FAILED').join('\\n');
    document.getElementById('dlBtn').classList.remove('hidden');
    loadAll();
    toast(lastBulk.filter(u => u.ok).length + ' users created');
  }

  function downloadBulk() {
    if (!lastBulk.length) return;
    const txt = lastBulk.filter(u => u.ok).map(u => u.email + ':' + u.password).join('\\n');
    const a = document.createElement('a');
    a.href = URL.createObjectURL(new Blob([txt], { type: 'text/plain' }));
    a.download = 'developerx-users.txt';
    a.click();
  }

  // ── Edit modal ──
  function openEdit(uid) {
    const u = allUsers.find(x => x.user_id === uid);
    if (!u) return;
    document.getElementById('editUserId').value = u.user_id;
    document.getElementById('editName').value = u.display_name || '';
    document.getElementById('editEmail').value = u.email || '';
    document.getElementById('editPlan').value = u.plan || 'trial';
    document.getElementById('editHours').value = u.credit_hours ?? 5;
    document.getElementById('editMinutes').value = u.credit_minutes ?? 0;
    document.getElementById('editTrialH').value = u.trial_hours ?? 5;
    document.getElementById('editTrialUsed').value = String(u.trial_used ?? false);
    document.getElementById('editDisabled').value = String(u.disabled ?? false);
    document.getElementById('editExpires').value = u.expires_at || '';
    document.getElementById('editModal').classList.add('open');
  }

  function closeModal() {
    document.getElementById('editModal').classList.remove('open');
  }

  async function saveEdit() {
    const uid = document.getElementById('editUserId').value;
    const body = {
      user_id: uid,
      display_name: document.getElementById('editName').value,
      plan: document.getElementById('editPlan').value,
      credit_hours: Number(document.getElementById('editHours').value) || 0,
      credit_minutes: Number(document.getElementById('editMinutes').value) || 0,
      trial_hours: Number(document.getElementById('editTrialH').value),
      trial_used: document.getElementById('editTrialUsed').value === 'true',
      disabled: document.getElementById('editDisabled').value === 'true',
      expires_at: document.getElementById('editExpires').value || null,
    };

    const r = await api('/admin/users/update', {
      method: 'POST',
      body: JSON.stringify(body)
    });

    if (r.ok) {
      closeModal();
      loadAll();
      toast('✅ User updated');
    } else {
      toast('❌ ' + (r.error || 'Error'));
    }
  }

  // ── Quick actions ──
  async function resetCredits(uid) {
    await api('/admin/users/reset-credits', {
      method: 'POST',
      body: JSON.stringify({ user_id: uid })
    });
    loadAll();
    toast('Credits reset to 0');
  }

  async function toggleUser(uid) {
    await api('/admin/users/toggle', {
      method: 'POST',
      body: JSON.stringify({ user_id: uid })
    });
    loadAll();
  }

  async function deleteUser(uid) {
    if (!confirm('Delete this user permanently?')) return;
    await api('/admin/users/delete', {
      method: 'POST',
      body: JSON.stringify({ user_id: uid })
    });
    loadAll();
    toast('User deleted');
  }

  // ── Cookies ──
  let cookieUploadVisible = false;
  function toggleCookieUpload() {
    cookieUploadVisible = !cookieUploadVisible;
    document.getElementById('cookieUpload').classList.toggle('hidden', !cookieUploadVisible);
  }

  async function fetchLiveCookies(btn) {
    var orig = btn.textContent;
    btn.disabled = true; btn.textContent = 'Fetching...';
    try {
      const r = await api('/admin/cookies/fetch-live', { method: 'POST', body: JSON.stringify({}) });
      if (r.ok) {
        document.getElementById('cookieCount').textContent = r.count + ' live cookies from veoly.netlify.app';
        document.getElementById('cookieCount').style.color = '#10b981';
        listCookies(); // refresh count
      } else {
        document.getElementById('cookieCount').textContent = 'Error: ' + (r.error || 'fetch failed');
        document.getElementById('cookieCount').style.color = '#ef4444';
      }
    } catch (e) {
      document.getElementById('cookieCount').textContent = 'Fetch error: ' + e.message;
      document.getElementById('cookieCount').style.color = '#ef4444';
    }
    btn.disabled = false; btn.textContent = orig;
  }

  async function listCookies() {
    const r = await api('/admin/cookies');
    document.getElementById('cookieCount').textContent = (r.count || 0) + ' cookies loaded';
  }

  async function uploadCookies() {
    const raw = document.getElementById('cookieJson').value.trim();
    let arr;
    try { arr = JSON.parse(raw); } catch (e) { return toast('Invalid JSON'); }
    if (!Array.isArray(arr)) arr = arr.cookies || [];
    const r = await api('/admin/cookies/update', {
      method: 'POST',
      body: JSON.stringify({ cookies: arr })
    });
    toast(r.ok ? '✅ ' + r.count + ' cookies updated' : '❌ Error');
    listCookies();
  }

  // ── Ledger ──
  async function loadLedger() {
    const r = await api('/admin/ledger');
    if (!r.entries) return;
    const tbody = document.getElementById('ledgerTbody');
    tbody.innerHTML = '';
    r.entries.slice(0, 80).forEach(e => {
      const tr = document.createElement('tr');
      tr.innerHTML =
        '<td style="font-size:11px">' + new Date(e.created_at).toLocaleString() + '</td>' +
        '<td><span class="mono">' + esc(e.email) + '</span></td>' +
        '<td style="color:' + (e.amount < 0 ? 'var(--red)' : 'var(--green)') + '">' + e.amount + '</td>' +
        '<td>' + e.balance_after + '</td>' +
        '<td>' + esc(e.reason) + '</td>';
      tbody.appendChild(tr);
    });
  }

  // ── Close modal on overlay click ──
  document.getElementById('editModal').addEventListener('click', function(e) {
    if (e.target === this) closeModal();
  });

  // ── Close modal on Escape ──
  document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape') closeModal();
  });
</script>
</body>
</html>`;

// ═══════════════════════════════════════════════════
//  Start
// ═══════════════════════════════════════════════════
server.listen(PORT, () => {
  console.log('');
  console.log('═══════════════════════════════════════════');
  console.log('  DeveloperX SaaS API Server');
  console.log('  http://localhost:' + PORT + '  ← Admin Panel');
  console.log('  Admin Key: ' + getAdminKey());
  console.log('  DB:        ' + DB_FILE);
  console.log('═══════════════════════════════════════════');
  console.log('');
});
