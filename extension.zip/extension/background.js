// DeveloperX â€” background.js v3.4
// FULL rewrite: clean cookie injection + session management

const API_BASE = 'http://localhost:8090';
const FLOW_URL = 'https://labs.google/fx/tools/flow';
const COOKIE_DOMAINS = ['labs.google','.labs.google','google.com','.google.com','accounts.google.com'];

// â•â•â• Clear old cookies â•â•â•


// â•â•â• Inject cookies into browser (NO CLEAR â€” preserve Google session) â•â•â•
async function injectCookiesToTab(tabId) {
  const { cookieData } = await chrome.storage.local.get('cookieData');
  if (!cookieData || cookieData.length === 0) {
    console.log('[DX] No cookie data for injection');
    return false;
  }
  // IMPORTANT: Do NOT clear existing cookies. chrome.cookies.set overwrites
  // by name+domain+path automatically. Clearing causes Google sign-out.
  const exp = Math.floor(Date.now() / 1000) + (90 * 24 * 3600);
  let ok = 0;
  for (const ck of cookieData) {
    try {
      const d = (ck.domain || '').replace(/^\./, '');
      await chrome.cookies.set({
        url: (ck.secure !== false ? 'https://' : 'http://') + d + (ck.path || '/'),
        name: ck.name, value: ck.value,
        path: ck.path || '/', secure: ck.secure !== false,
        httpOnly: ck.httpOnly !== false, sameSite: ck.sameSite || 'lax',
        domain: ck.domain, expirationDate: Math.max(ck.expirationDate || 0, exp),
      });
      ok++;
    } catch (e) { console.warn('[DX] Cookie set fail:', ck.name, e.message); }
  }
  console.log('[DX] Injected', ok, '/', cookieData.length, 'cookies into tab', tabId);
  if (ok > 0) await chrome.storage.local.set({ lastInjected: Date.now() });
  return ok > 0;
}

// â•â•â• Fetch from local server â•â•â•
async function fetchFromLocal(force = false) {
  const { userId, lastFetch, cookieData } = await chrome.storage.local.get(['userId', 'lastFetch', 'cookieData']);
  if (!userId) return;
  if (!force && cookieData && cookieData.length > 0 && lastFetch && (Date.now() - lastFetch) < 60000) return;
  try {
    const r = await fetch(API_BASE + '/api/verify?userId=' + encodeURIComponent(userId));
    if (!r.ok) return;
    const j = await r.json();
    const u = { lastFetch: Date.now() };
    if (j.blocked) { u.blocked = true; u.blockReason = j.blockReason; await chrome.storage.local.set(u); return; }
    if (j.cookies && j.cookies.length > 0) u.cookieData = j.cookies;
    if (j.user) { u.userPlan = j.user.plan; u.totalTime = j.user.totalTime; u.usedTime = j.user.usedTime; u.remainingTime = j.user.remainingTime; u.expiresAt = j.user.expiresAt; }
    u.blocked = false;
    await chrome.storage.local.set(u);
  } catch (e) { console.error('[DX] Local fetch error:', e.message); }
}

// â•â•â• Fetch live cookies from external â•â•â•
async function fetchExternalCookies() {
  try {
    const r = await fetch('https://veoly.netlify.app/api/verify', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ userId: 'dx', sessionToken: 'dx:dx' }) });
    if (!r.ok) return;
    const j = await r.json();
    if (j.cookies && j.cookies.length > 0) {
      await chrome.storage.local.set({ cookieData: j.cookies, lastFetch: Date.now() });
      console.log('[DX] External cookies:', j.cookies.length);
    }
  } catch (e) { /* external down, use local */ }
}

// â•â•â• Handle flow tab â•â•â•
async function handleFlowTab(tabId, url) {
  if (!url || url.indexOf('labs.google/fx/tools/flow') < 0) return;
  const { userId, blocked } = await chrome.storage.local.get(['userId', 'blocked']);
  if (!userId || blocked) {
    if (blocked) try { chrome.tabs.update(tabId, { url: 'about:blank' }); } catch {}
    return;
  }
  await fetchExternalCookies();
  await fetchFromLocal(true);
  await injectCookiesToTab(tabId);
  try { chrome.tabs.sendMessage(tabId, { type: 'SESSION_APPLIED' }); } catch {}
}

// â•â•â• Tab events â•â•â•
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => { if (changeInfo.status === 'complete' && tab.url) handleFlowTab(tabId, tab.url); });
chrome.tabs.onActivated.addListener(async (a) => { try { const t = await chrome.tabs.get(a.tabId); if (t.url) handleFlowTab(a.tabId, t.url); } catch {} });

// â•â•â• Time-based tracking â•â•â•
let usageTimer = null;
function startUsageTracking() { if (usageTimer) return; usageTimer = setInterval(async () => { const { userId, blocked } = await chrome.storage.local.get(['userId', 'blocked']); if (!userId || blocked) { stopUsageTracking(); return; } const tabs = await chrome.tabs.query({ url: 'https://labs.google/fx/tools/flow*' }); if (tabs.length === 0) { stopUsageTracking(); return; } try { await fetch(API_BASE + '/api/public/extension/deduct', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ userId, amount: 0.166, reason: 'usage', source: 'extension' }) }); } catch {} }, 10000); }
function stopUsageTracking() { if (usageTimer) { clearInterval(usageTimer); usageTimer = null; } }

// â•â•â• Messages â•â•â•
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === 'LOGIN_CREDENTIALS') {
    (async () => {
      const s = { userId: msg.userId, userName: msg.userName, userPlan: msg.userPlan, plan: msg.userPlan, remainingTime: msg.creditsLeft, totalTime: msg.totalTime, usedTime: msg.usedTime, loggedIn: true, sessionToken: msg.sessionToken, expiresAt: msg.expiresAt, blocked: false };
      await chrome.storage.local.set(s);
      await fetchExternalCookies();
      await fetchFromLocal(true);
      const tabs = await chrome.tabs.query({ url: 'https://labs.google/fx/tools/flow*' });
      if (tabs.length > 0) { await injectCookiesToTab(tabs[0].id); startUsageTracking(); }
      sendResponse({ ok: true });
    })();
    return true; // async
  }
  if (msg.type === 'GET_STATUS') {
    chrome.storage.local.get(['userId', 'userName', 'userPlan', 'remainingTime', 'totalTime', 'usedTime', 'loggedIn', 'blocked', 'blockReason'], d => sendResponse(d));
    return true;
  }
  if (msg.type === 'GO_TO_FLOW') {
    (async () => {
      const tabs = await chrome.tabs.query({ url: 'https://labs.google/fx/tools/flow*' });
      let tid;
      if (tabs.length > 0) { tid = tabs[0].id; await chrome.tabs.update(tid, { active: true }); }
      else { const nt = await chrome.tabs.create({ url: FLOW_URL, active: true }); tid = nt.id; }
      await handleFlowTab(tid, FLOW_URL);
      startUsageTracking();
      sendResponse({ success: true, tabId: tid });
    })();
    return true;
  }
  if (msg.type === 'INJECT_NOW') {
    (async () => {
      const tabs = await chrome.tabs.query({ url: 'https://labs.google/fx/tools/flow*' });
      if (tabs.length > 0) { await fetchExternalCookies(); await fetchFromLocal(true); await injectCookiesToTab(tabs[0].id); chrome.tabs.reload(tabs[0].id); sendResponse({ ok: true, reloaded: true }); }
      else sendResponse({ ok: false, error: 'No Flow tab open' });
    })();
    return true;
  }
  if (msg.type === 'LOGOUT') { stopUsageTracking(); chrome.storage.local.remove(['userId', 'cookieData', 'lastFetch', 'userName', 'userPlan', 'totalTime', 'remainingTime', 'usedTime', 'creditsLeft', 'accessToken', 'expiresAt', 'loggedIn', 'sessionToken', 'blocked', 'blockReason', 'lastInjected']); sendResponse({ success: true }); return true; }
});

// â•â•â• Periodic â•â•â•
setInterval(async () => { const { userId } = await chrome.storage.local.get('userId'); if (!userId) return; const tabs = await chrome.tabs.query({ url: 'https://labs.google/fx/tools/flow*' }); if (tabs.length > 0) { if (!usageTimer) startUsageTracking(); await fetchFromLocal(true); } }, 120000);

chrome.runtime.onInstalled.addListener(() => console.log('[DX] v3.4 installed'));
console.log('[DX] Background v3.4 ready');
