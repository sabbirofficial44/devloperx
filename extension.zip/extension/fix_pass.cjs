const fs=require('fs');
let server=fs.readFileSync('D:/Script/VeuUnlimited/extension/dev-server.js','utf8');

// Fix DASHBOARD_HTML pass line - use the actual pattern from the file
const searchPattern = 'var pass=';
const pos=server.indexOf(searchPattern);
if(pos>=0){
  // Read the line to understand what's there
  const snippet=server.substring(pos,pos+200);
  console.log('Found pass line:',snippet.substring(0,80));
  
  // Check if already has getElementById
  if(snippet.includes('getElementById')){
    console.log('  -> Already has getElementById, checking for corruption');
    // The corruption is the "…" character - it was meant to be ".getElementById"
    // Actually the real bytes should be correct, let me verify
    
    // Find semicolon after this
    const semiEnd=snippet.indexOf(';');
    const fullLine=snippet.substring(0,semiEnd+1);
    console.log('  Full line:',fullLine);
    
    // Fix: replace the whole line
    const newLine='var pw=document.getElementById("password").value||"pass"';
    server=server.substring(0,pos)+newLine+';'+server.substring(pos+semiEnd+1);
    console.log('  -> Rewritten to use pw instead of pass');
  } else {
    // No getElementById - fully corrupted
    const semiEnd=snippet.indexOf(';');
    const newLine='var pw=document.getElementById("password").value||"pass"';
    server=server.substring(0,pos)+newLine+';'+server.substring(pos+semiEnd+1);
    console.log('  -> Fixed corrupted pass line');
  }
} else {
  console.log('No var pass= found in server');
}

// Also fix popup.js just in case
let popup=fs.readFileSync('D:/Script/VeuUnlimited/extension/popup.js','utf8');
const passPos2=popup.indexOf('var pass=');
if(passPos2>=0){
  const snippet2=popup.substring(passPos2,passPos2+200);
  console.log('\npopup.js pass:',snippet2.substring(0,80));
  if(snippet2.includes('getElementById')){
    console.log('  popup.js has getElementById - OK');
  }
}

fs.writeFileSync('D:/Script/VeuUnlimited/extension/dev-server.js',server,'utf8');
console.log('\nServer saved. Restarting...');
