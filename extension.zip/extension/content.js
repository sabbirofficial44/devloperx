// DeveloperX — content.js v2.0
// FIX: Gmail block disabled on Flow page (was causing signout)
// Only live time badge + plan sync

(function(){
var badge=null,timerId=null,remaining=0;

// ═══ Live countdown badge ═══
function createBadge(){
  if(badge)return;
  badge=document.createElement('div');
  badge.id='dx-badge';
  badge.innerHTML='<div style="font-size:13px;font-weight:700;margin-bottom:2px"><span id="dx-plan">—</span> · <span id="dx-clock">—</span></div><div style="font-size:10px;opacity:.7">Time used: <span id="dx-used">—</span></div>';
  badge.style.cssText='position:fixed;top:12px;right:12px;z-index:99999;background:linear-gradient(135deg,#7c3aed,#a855f7);color:#fff;padding:10px 14px;border-radius:10px;font-family:system-ui;box-shadow:0 4px 24px rgba(124,58,237,.5);min-width:140px;text-align:center;pointer-events:none;';
  document.body.appendChild(badge);
}

function pad(n){return n<10?'0'+n:n}

function updateBadge(){
  if(remaining<=0){
    document.getElementById('dx-clock').textContent='EXPIRED';
    document.getElementById('dx-used').textContent='Upgrade now';
    badge.style.background='linear-gradient(135deg,#ef4444,#dc2626)';
    return;
  }
  var h=Math.floor(remaining/3600),m=Math.floor((remaining%3600)/60),s=Math.floor(remaining%60);
  document.getElementById('dx-clock').textContent=pad(h)+':'+pad(m)+':'+pad(s);
}

function loadState(data){
  if(!badge)createBadge();
  var plan=(data.userPlan||data.plan||'trial').toUpperCase();
  document.getElementById('dx-plan').textContent=plan;
  if(data.remainingTime!==undefined)remaining=data.remainingTime*60;
  else if(data.creditsLeft!==undefined)remaining=data.creditsLeft*60;
  var totalS=data.totalTime!==undefined?data.totalTime*60:0;
  var usedS=Math.max(0,totalS-remaining);
  var uh=Math.floor(usedS/3600),um=Math.floor((usedS%3600)/60);
  document.getElementById('dx-used').textContent=uh+'h '+um+'m';
  updateBadge();
}

function showToast(text,type){
  var el=document.createElement('div');
  el.style.cssText='position:fixed;top:12px;right:12px;z-index:999999;padding:10px 16px;border-radius:8px;font-size:13px;font-family:system-ui;color:#fff;pointer-events:none;transition:opacity .3s;opacity:1;max-width:320px;box-shadow:0 4px 20px rgba(0,0,0,.4);';
  el.style.background=type==='blocked'?'#ef4444':'#10b981';
  el.textContent=text;document.body.appendChild(el);
  setTimeout(function(){el.style.opacity='0';setTimeout(function(){el.remove()},300)},4000);
}

// ═══ Timer ═══
function startTimer(){
  if(timerId)return;
  timerId=setInterval(function(){
    if(remaining>0){remaining--;updateBadge();if(remaining<=0){clearInterval(timerId);timerId=null;showToast('Time expired — Upgrade now','blocked')}}
  },1000);
}

// ═══ Init ═══
chrome.storage.local.get(['userPlan','plan','totalTime','remainingTime','usedTime','creditsLeft','loggedIn'],function(d){
  if(d.loggedIn){loadState(d);startTimer()}
});

chrome.storage.onChanged.addListener(function(changes){
  var d={};
  for(var k in changes){if(changes[k])d[k]=changes[k].newValue}
  if(d.userPlan||d.totalTime!==undefined||d.remainingTime!==undefined||d.creditsLeft!==undefined){
    loadState(Object.assign(d,{loggedIn:true}));
    if(!timerId)startTimer();
  }
  if(changes.blocked&&changes.blocked.newValue){
    clearInterval(timerId);timerId=null;
    showToast('⚠ ' + ((changes.blockReason||{}).newValue||'Account blocked'),'blocked');
  }
});

setInterval(function(){
  chrome.storage.local.get(['userPlan','totalTime','remainingTime','creditsLeft'],function(d){
    if(d.remainingTime!==undefined||d.totalTime!==undefined||d.creditsLeft!==undefined)loadState(d);
  });
},60000);

chrome.runtime.onMessage.addListener(function(msg){
  if(msg.type==='SESSION_APPLIED')showToast('DX Active ('+(msg.count||'')+' cookies)');
  if(msg.type==='BLOCKED'){showToast('⚠ '+(msg.reason||'Blocked'),'blocked');clearInterval(timerId);timerId=null}
});

console.log('[DX] Content ready — timer badge only, no Gmail lock');
})();
